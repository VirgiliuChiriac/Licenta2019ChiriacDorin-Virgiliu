function initEditContent(){
    scope.edit = {
        loading: false,
        channelImage: '../../resources/images/upload-image.svg',
        coverImage: '../../resources/images/upload-image.svg',

        channelLinks:[{name:'Website',url:'', id:0},{name:'Facebook',url:'', id:1},{name:'',url:'', id:2}],
        linksChange: linksChange,
        save: save,
        files:{
            channelImage: '',
            coverImage: ''
        },
        chName: '',
        chDescription: '',
        chContact: '',
        chNameChanged: function(){ scope.edit.error.nameExists = false; scope.edit.error.nameNull = false;},
        chUsabilityChanged: function(){ scope.edit.error.postUsability = false;},
        error: {
            nameNull: false,
            nameExists: false,
            chImgSize: false,
            chImgFileType: false,
            covImgSize: false,
            covImgFileType: false,

            selectionCh: false,
            selectionColl: false,

            postUsability: false,
            postType: false,
            nsfw: false,
        },

        isEdit: false,
        retrievingData: true,
        channelToEdit:{},

        selectEditOption: selectEditOption,
        collectionsSelection: [],
        collectionsSelectionObj: {},

        retrievingCollectionsData: true,

        postContent:{
            type: 'image',
            videoURL: '',
            imageURL: '',
            articleTitle: '',
            articleURL: '',
            postType: '',
            nsfw: '',
            source: ''
        },

        notifications: 'on',
        imageURLChange: imageURLChange,

        deleteContent: deleteContent
    };

    if(scope.index.page.urlVars.id !== undefined){
        scope.edit.isEdit = true;

        if(scope.index.page.urlVars.page === 'CHANNEL'){
            firebase.database().ref("public/channels/" + scope.index.page.urlVars.id).once("value").then(function(snapshot) {
                if(snapshot.val() !== null){
                    scope.edit.channelToEdit = snapshot.val();

                    scope.edit.chName= snapshot.val().identity.name;
                    scope.edit.channelImage = snapshot.val().identity.profilePic;
                    scope.edit.coverImage = snapshot.val().identity.coverPic;

                    //channel links
                    if(snapshot.val().about !== undefined){
                        if(snapshot.val().about.links !== undefined){ 
                            scope.edit.channelLinks = snapshot.val().about.links;
                            scope.edit.channelLinks.push({name:'',url:'', id:snapshot.val().about.links.length});
                        }

                        scope.edit.chDescription = snapshot.val().about.description !== undefined ? snapshot.val().about.description : '';
                        scope.edit.chContact = snapshot.val().about.contact !== undefined ? snapshot.val().about.contact : '';
                    }

                    scope.edit.retrievingData = false;
                    scope.$applyAsync();
                } else {
                    changeURL('/404');
                }
            });

            var uid = firebase.auth().currentUser.uid;
            firebase.database().ref("private/" + uid + '/stopNotifications/' + scope.index.page.urlVars.id).once("value").then(function(snapshot) {
                if(snapshot.val() !== null){
                    scope.edit.notifications = 'off';
                }
            });
        }

        if(scope.index.page.urlVars.page === 'COLLECTION'){
            firebase.database().ref("public/collections/" + scope.index.page.urlVars.id).once("value").then(function(snapshot) {
                if(snapshot.val() !== null){
                    scope.index.editSelections.channel = snapshot.val().channel;
                    scope.edit.chName = snapshot.val().content.name;
                    scope.edit.chDescription = snapshot.val().content.description;

                    scope.edit.retrievingData = false;
                    scope.$applyAsync();
                } else {
                    changeURL('/404');
                }
            });
        }

        if(scope.index.page.urlVars.page === 'POST'){
            firebase.database().ref("public/posts/" + scope.index.page.urlVars.id).once("value").then(function(snapshot) {
                if(snapshot.val() !== null){
                    scope.index.editSelections.channel = snapshot.val().channel;
                    getEditCollections(snapshot.val().channel);

                    scope.edit.postContent={
                        type: snapshot.val().ref.type,
                        videoURL: snapshot.val().ref.videoURL ? snapshot.val().ref.videoURL : '',
                        articleTitle: snapshot.val().ref.articleTitle ? snapshot.val().ref.articleTitle : '',
                        articleURL: snapshot.val().ref.articleURL ? snapshot.val().ref.articleURL : '',
                    };
                    scope.edit.coverImage = snapshot.val().ref.imageURL;

                    scope.index.editSelections.collection = snapshot.val().content.collection;
                    scope.edit.chName = snapshot.val().content.title;
                    scope.edit.chDescription = snapshot.val().content.usability;
                    scope.edit.postContent.postType = snapshot.val().content.type;
                    scope.index.editSelections.category = snapshot.val().content.category;
                    scope.edit.postContent.nsfw = snapshot.val().content.nsfw;
                    scope.edit.postContent.source = snapshot.val().content.source;
                    
                    if(snapshot.val().content.links !== undefined){ 
                        scope.edit.channelLinks = snapshot.val().content.links;
                        scope.edit.channelLinks.push({name:'',url:'', id:snapshot.val().content.links.length});
                    }

                    scope.edit.retrievingData = false;
                    scope.$applyAsync();
                } else {
                    changeURL('/404');
                }
            });

            var uid = firebase.auth().currentUser.uid;
            firebase.database().ref("private/" + uid + '/stopNotifications/' + scope.index.page.urlVars.id).once("value").then(function(snapshot) {
                if(snapshot.val() !== null){
                    scope.edit.notifications = 'off';
                }
            });
        }
    } else {
        if(scope.index.page.urlVars.page === 'POST' && scope.index.editSelections.channel !== ''){
            getEditCollections(scope.index.editSelections.channel);
        }
    }

    if(scope.index.page.urlVars.page === 'POST'){
        scope.edit.channelLinks=[{name:'', url: ''}];
        scope.index.editSelections.category = '';
        initCategoriesContent();
        scope.$applyAsync();
    }
}

function linksChange(channelLinks){ // for links of the channel
    index = scope.edit.channelLinks.length - 1;

    if(scope.edit.channelLinks[index].name !== '' || scope.edit.channelLinks[index].url !== ''){
        scope.edit.channelLinks.push({name:'', url:'', id: scope.edit.channelLinks[index].id + 1});
    }

    var ok = true;
    while(ok){
        ok = false;
        index = scope.edit.channelLinks.length - 1;
        if(scope.edit.channelLinks[index-1] !== undefined && scope.edit.channelLinks[index-1].name === '' && scope.edit.channelLinks[index-1].url === '' && index > (scope.index.page.urlVars.page === 'POST' ? 0 : 1)){
            scope.edit.channelLinks.pop();
            ok = true;
        }
    }
}

function save(){
    if(scope.index.page.urlVars.page === 'POST'){
        if(scope.index.editSelections.channel === ''){
            scope.edit.error.selectionCh = true;
        }

        if(scope.index.editSelections.collection === ''){
            scope.edit.error.selectionColl = true;
        }

        if(scope.edit.chDescription.replace(/\s/g, "") === ''){
            scope.edit.error.postUsability = true;
        }

        if(scope.edit.postContent.postType === ''){
            scope.edit.error.postType = true;
        }

        if(scope.edit.postContent.nsfw === ''){
            scope.edit.error.nsfw = true;
        }
    } else {
        if(scope.edit.chName.replace(/\s/g, "") === ''){
            scope.edit.error.nameNull = true;
        }
    
        if(scope.index.page.urlVars.page === 'COLLECTION' && scope.index.editSelections.channel === ''){
            scope.edit.error.selectionCh = true;
        }
    }
    scope.$applyAsync();

    if(!scope.edit.loading && noEditErrors()){
        scope.edit.loading = true;
        var uid = firebase.auth().currentUser.uid;

        if(scope.index.page.urlVars.page === 'CHANNEL'){
            var name = scope.edit.chName;
            var id = name.toLowerCase().replace(/\s/g, "");
            var noError = true;

            if(!scope.edit.isEdit){
                firebase.database().ref('public/channels/' + id).set({
                    uid: uid
                }).catch(function(error){
                    noError = false;
                    scope.edit.error.nameExists = true;
                    scope.edit.loading = false;
                }).then(function(){
                    if(noError){
                        channelPublic = {
                            uid: uid,
                            identity:{
                                id: id,
                                name: name,
                                profilePic: scope.edit.isEdit ? scope.edit.channelToEdit.identity.profilePic : local.profilePic,
                                coverPic: scope.edit.isEdit ? scope.edit.channelToEdit.identity.coverPic : local.coverPic
                            },
                            about:{
                                description: scope.edit.chDescription,
                                links: [],
                                contact: scope.edit.chContact
                            },
                            values: {
                                subscribers: 0,
                                likes: 0
                            }
                        };
                        for( var i = 0; i < scope.edit.channelLinks.length ; i++){
                            if(scope.edit.channelLinks[i].name !== '' && scope.edit.channelLinks[i].url !== ''){
                                channelPublic.about.links.push({
                                    name:scope.edit.channelLinks[i].name,
                                    url:scope.edit.channelLinks[i].url,
                                    id: channelPublic.about.links.length
                                });
                            }
                        }
    
                        channelPrivate = {
                            id: id,
                            name: name,
                            profilePic: scope.edit.isEdit ? scope.edit.channelToEdit.identity.profilePic : local.profilePic,
                            coverPic: scope.edit.isEdit ? scope.edit.channelToEdit.identity.coverPic : local.coverPic
                        };
    
                        function saveChannelInDatabase(){
                            var countt = 2;
                            firebase.database().ref('public/channels/' + id).set(channelPublic).then(function(){
                                if( countt === 1){
                                    getUserData(firebase.auth().currentUser);
                                    changeURL('/channel/' + id);
                                } else {
                                    countt--;
                                }
                            });
                            firebase.database().ref('private/' + uid + '/user/channels/' + id).set(channelPrivate).then(function(){
                                if( countt === 1){
                                    getUserData(firebase.auth().currentUser);
                                    changeURL('/channel/' + id);
                                } else {
                                    countt--;
                                }
                            });

                            firebase.database().ref('public/collections/').push({
                                uid: uid,
                                channel: id,
                                content:{
                                    name: '(default)',
                                    description: ''
                                },
                                values:{
                                    nrPosts: 0,
                                    thumbnail: local.coverPic
                                }
                            })
                        }
    
                        var count = 0;
                        scope.edit.files.channelImage !== '' ? count++ : '';
                        scope.edit.files.coverImage !== '' ? count++ : '';
    
                        if(scope.edit.files.channelImage !== ''){
                            var picChId = id + '-channelImage';
                            firebase.storage().ref().child('/usersPictures/'+ uid +'/' + picChId).put(scope.edit.files.channelImage).then(function(snapshot) {
                                channelPublic.identity.profilePic = snapshot.downloadURL;
                                channelPrivate.profilePic = snapshot.downloadURL;
    
                                if(count === 1){
                                    saveChannelInDatabase();
                                } else {
                                    count --;
                                }
                            });
                        }
    
                        if(scope.edit.files.coverImage !== ''){
                            var picCovId = id + '-coverImage';
                            firebase.storage().ref().child('/usersPictures/'+ uid +'/' + picCovId).put(scope.edit.files.coverImage).then(function(snapshot) {
                                channelPublic.identity.coverPic = snapshot.downloadURL;
                                channelPrivate.coverPic = snapshot.downloadURL;
    
                                if(count === 1){
                                    saveChannelInDatabase();
                                } else {
                                    count --;
                                }
                            });
                        }
    
                        if(count === 0){
                            saveChannelInDatabase();
                        }

                        notificationsStatus(id);
                    }
                    scope.$applyAsync();
                });
            } else {
                channelPublic = {
                    uid: uid,
                    identity:{
                        id: id,
                        name: name,
                        profilePic: scope.edit.channelToEdit.identity.profilePic,
                        coverPic: scope.edit.channelToEdit.identity.coverPic
                    },
                    about:{
                        description: scope.edit.chDescription,
                        links: [],
                        contact: scope.edit.chContact
                    },
                    values: {
                        subscribers: 0,
                        likes: 0
                    }
                };
                for( var i = 0; i < scope.edit.channelLinks.length ; i++){
                    if(scope.edit.channelLinks[i].name !== '' && scope.edit.channelLinks[i].url !== ''){
                        channelPublic.about.links.push({
                            name:scope.edit.channelLinks[i].name,
                            url:scope.edit.channelLinks[i].url,
                            id: channelPublic.about.links.length
                        });
                    }
                }

                channelPrivate = {
                    id: id,
                    name: name,
                    profilePic: scope.edit.channelToEdit.identity.profilePic,
                    coverPic:scope.edit.channelToEdit.identity.coverPic
                };

                function saveChannelInDatabase(){
                    var countt = 3;
                    firebase.database().ref('public/channels/' + id + '/identity').set(channelPublic.identity).then(function(){
                        if( countt === 1){
                            getUserData(firebase.auth().currentUser);
                            changeURL('/channel/' + id);
                        } else {
                            countt--;
                        }
                    });
                    firebase.database().ref('public/channels/' + id + '/about').set(channelPublic.about).then(function(){
                        if( countt === 1){
                            getUserData(firebase.auth().currentUser);
                            changeURL('/channel/' + id);
                        } else {
                            countt--;
                        }
                    });
                    firebase.database().ref('private/' + uid + '/user/channels/' + id).set(channelPrivate).then(function(){
                        if( countt === 1){
                            getUserData(firebase.auth().currentUser);
                            changeURL('/channel/' + id);
                        } else {
                            countt--;
                        }
                    });
                }

                var count = 0;
                scope.edit.files.channelImage !== '' ? count++ : '';
                scope.edit.files.coverImage !== '' ? count++ : '';

                if(scope.edit.files.channelImage !== ''){
                    var picChId = id + '-channelImage';
                    firebase.storage().ref().child('/usersPictures/'+ uid +'/' + picChId).put(scope.edit.files.channelImage).then(function(snapshot) {
                        channelPublic.identity.profilePic = snapshot.downloadURL;
                        channelPrivate.profilePic = snapshot.downloadURL;

                        if(count === 1){
                            saveChannelInDatabase();
                        } else {
                            count --;
                        }
                    });
                }

                if(scope.edit.files.coverImage !== ''){
                    var picCovId = id + '-coverImage';
                    firebase.storage().ref().child('/usersPictures/'+ uid +'/' + picCovId).put(scope.edit.files.coverImage).then(function(snapshot) {
                        channelPublic.identity.coverPic = snapshot.downloadURL;
                        channelPrivate.coverPic = snapshot.downloadURL;

                        if(count === 1){
                            saveChannelInDatabase();
                        } else {
                            count --;
                        }
                    });
                }

                if(count === 0){
                    saveChannelInDatabase();
                }

                notificationsStatus(id);
            }
        }

        if(scope.index.page.urlVars.page === 'COLLECTION'){
            if(!scope.edit.isEdit){
                var collectionId = firebase.database().ref('public/collections/').push({
                    uid: uid,
                    channel: scope.index.editSelections.channel,
                    content:{
                        name: scope.edit.chName,
                        description: scope.edit.chDescription
                    },
                    values:{
                        nrPosts: 0,
                        thumbnail: local.coverPic
                    }
                }).key;

                function checkCollectionId(){
                    if(collectionId !== undefined){
                        firebase.database().ref('public/collections/' + collectionId + '/content').update({
                            nameSearch: scope.edit.chName.toLowerCase().replace(/\s/g, "") + collectionId
                        });
                        changeURL('/collection/' + collectionId)
                    } else {
                        setTimeout(checkCollectionId, 50);
                    }
                }
                checkCollectionId();
            } else {
                firebase.database().ref('public/collections/' + scope.index.page.urlVars.id + '/content').set({
                    name: scope.edit.chName,
                    nameSearch: scope.edit.chName.toLowerCase().replace(/\s/g, "") + scope.index.page.urlVars.id,
                    description: scope.edit.chDescription
                }).then(function(){
                    changeURL('/collection/' + scope.index.page.urlVars.id)
                });
            }
        }

        if(scope.index.page.urlVars.page === 'POST'){
            if(!scope.edit.isEdit){
                if(['image','article'].indexOf(scope.edit.postContent.type) !== -1){
                    var postId = firebase.database().ref('public/posts/').push({
                        uid: uid,
                        channel: scope.index.editSelections.channel,
                    }).key;

                    function checkPostId(){
                        if(postId !== undefined){
                            if(scope.edit.files.coverImage !== ''){
                                var picId = postId;
                                firebase.storage().ref().child('/usersPictures/'+ uid +'/' + picId).put(scope.edit.files.coverImage).then(function(snapshot) {
                                    firebase.database().ref('public/posts/' + postId + '/ref').set({
                                        type: scope.edit.postContent.type,
                                        imageURL: snapshot.downloadURL,
                                        articleTitle: scope.edit.postContent.type === 'article' ? scope.edit.postContent.articleTitle : '',
                                        articleURL: scope.edit.postContent.type === 'article' ? scope.edit.postContent.articleURL : ''
                                    });
                                    setPostContent(postId, scope.index.editSelections.channel);
                                });
                            } else {
                                firebase.database().ref('public/posts/' + postId + '/ref').set({
                                    type: scope.edit.postContent.type,
                                    imageURL: scope.edit.postContent.imageURL === '' ? local.coverPic : scope.edit.postContent.imageURL,
                                    articleTitle: scope.edit.postContent.type === 'article' ? scope.edit.postContent.articleTitle : '',
                                    articleURL: scope.edit.postContent.type === 'article' ? scope.edit.postContent.articleURL : ''
                                });
                                setPostContent(postId, scope.index.editSelections.channel);
                            }
                        } else {
                            setTimeout(checkPostId, 50);
                        }
                    }
                    checkPostId();
                } else {
                    var links = [];
                    for( var i = 0; i < scope.edit.channelLinks.length ; i++){
                        if(scope.edit.channelLinks[i].name !== '' && scope.edit.channelLinks[i].url !== ''){
                            links.push({
                                name:scope.edit.channelLinks[i].name,
                                url:scope.edit.channelLinks[i].url,
                                id: links.length
                            });
                        }
                    }

                    var postId = firebase.database().ref('public/posts/').push({
                        uid: uid,
                        channel: scope.index.editSelections.channel,
                        ref:{
                            type: scope.edit.postContent.type,
                            videoURL: scope.edit.postContent.videoURL,
                            imageURL: scope.index.getYotubeVideoUrl(scope.edit.postContent.videoURL, true)
                        },
                        content: {
                            collection:scope.index.editSelections.collection,
                            title: scope.edit.chName,
                            usability: scope.edit.chDescription,
                            type:  scope.edit.postContent.postType,
                            category: scope.index.editSelections.category,
                            nsfw: scope.edit.postContent.nsfw,
                            source: scope.edit.postContent.source,
                            links: links
                        }
                    }).key;

                    function checkPostId(){
                        if(postId !== undefined){
                            setPostValues(postId, scope.index.editSelections.channel);
                            notificationsStatus(postId);
                            changeURL('/post/' + postId);
                        } else {
                            setTimeout(checkPostId, 50);
                        }
                    }
                    checkPostId();
                }
            } else {
                setPostContent(scope.index.page.urlVars.id, scope.index.editSelections.channel);
            }
        }
    }
}

function setPostContent(id, channel){
    var links = [];
    for( var i = 0; i < scope.edit.channelLinks.length ; i++){
        if(scope.edit.channelLinks[i].name !== '' && scope.edit.channelLinks[i].url !== ''){
            links.push({
                name:scope.edit.channelLinks[i].name,
                url:scope.edit.channelLinks[i].url,
                id: links.length
            });
        }
    }

    firebase.database().ref('public/posts/' + id + '/content').set({
        collection:scope.index.editSelections.collection,
        title: scope.edit.chName,
        usability: scope.edit.chDescription,
        type:  scope.edit.postContent.postType,
        category: scope.index.editSelections.category,
        nsfw: scope.edit.postContent.nsfw,
        source: scope.edit.postContent.source,
        links: links
    }).then(function(){
        notificationsStatus(id);
        changeURL('/post/' + id);
    });
    setPostValues(id, channel);
}

function setPostValues(id, channel){
    firebase.database().ref('public/posts/' + id + '/content').update({
        titleSearch: scope.edit.chName.toLowerCase().replace(/\s/g, "") + id,
    });
    if(!scope.edit.isEdit){
        firebase.database().ref('public/posts/' + id + '/values').set({
            likes: 0,
            comments: 0,
            collection: scope.index.editSelections.collection + id,
            //filters
            rating: 1 + id,
            type_new: scope.edit.postContent.postType + id,
            type_hot: scope.edit.postContent.postType + 1 + id,
            category_new: scope.index.editSelections.category.toUpperCase() + id,
            category_hot: scope.index.editSelections.category.toUpperCase() + 1 + id,
            channel_new: channel + '--/-//-' + id,
            channel_hot: channel + '--/-//-' + 1 + id
        });
    } else {
        firebase.database().ref('public/posts/' + id + '/values').update({collection: scope.index.editSelections.collection + id});
    }
}

function noEditErrors(){
    if(scope.index.page.urlVars.page === 'POST'){
        if(scope.edit.error.selectionCh || scope.edit.error.selectionColl || scope.edit.error.postUsability || scope.edit.error.postType || scope.edit.error.nsfw){
            return false;
        }        
    } else {
        if(scope.edit.error.nameExists || scope.edit.error.nameNull || scope.edit.error.selectionCh || scope.edit.error.selectionColl){
            return false
        }
    }
    return true;
}

function loadImage(event, pic){
    if(event.target.files[0] !== undefined){
        var error = false;
        var prefix = pic === 'channel' ? 'ch' : 'cov';
        if(pic === 'channel'){
            scope.edit.channelImage = scope.edit.isEdit ? scope.edit.channelToEdit.identity.profilePic : '../../resources/images/upload-image.svg';
            scope.edit.files.channelImage = '';
        } else {
            scope.edit.coverImage = scope.edit.isEdit ? scope.edit.channelToEdit.identity.coverPic : '../../resources/images/upload-image.svg';
            scope.edit.files.coverImage = '';
        }

        scope.edit.error[prefix + 'ImgSize'] = false;
        scope.edit.error[prefix + 'ImgFileType'] = false;

        if(event.target.files[0].size>1048576){
            scope.edit.error[prefix + 'ImgSize'] = true;
            error = true;
        }
        if(event.target.files[0].type.substring(0,5) !== 'image'){
            scope.edit.error[prefix + 'ImgFileType'] = true;
            error = true;
        }
        if(!error){
            if( prefix === 'ch'){
                scope.edit.files.channelImage = event.target.files[0];
                scope.edit.channelImage = URL.createObjectURL(event.target.files[0]);
            } else {
                scope.edit.files.coverImage = event.target.files[0];
                scope.edit.coverImage = URL.createObjectURL(event.target.files[0]);
            }
        }
        scope.edit.postContent.imageURL = '';
        scope.$applyAsync();
    }
}

function selectEditOption(selection, id){
    if(selection === 'channel'){
        if(scope.index.editSelections.channel != id){
            scope.index.editSelections.channel = id;
            scope.edit.error.selectionCh = false;

            scope.index.editSelections.collection = '';

            if(scope.index.page.urlVars.page === 'POST'){
                getEditCollections(scope.index.editSelections.channel);
            }
        }
    } 
    if(selection === 'collection'){
        scope.index.editSelections.collection = id;
        scope.edit.error.selectionColl = false;
    }

    if(selection === 'category'){
        scope.index.editSelections.category = id;
    }
    scope.$applyAsync();
}

function getEditCollections(id){
    scope.edit.retrievingCollectionsData = true;
    scope.edit.collectionsSelection = [];
    
    firebase.database().ref("public/collections/").orderByChild('channel').equalTo(id).once("value").then(function(snapshot) {
        if(snapshot.val() !== null){
            scope.edit.collectionsSelectionObj = snapshot.val();
            var array = Object.keys(snapshot.val());
            array.forEach(function(item){
                obj = snapshot.val()[item];
                obj.id = item;
                scope.edit.collectionsSelection.push(obj);
            });
        }

        scope.edit.retrievingCollectionsData = false;
        scope.$applyAsync();

        console.log(scope.edit.collectionsSelection);
    });
}

function notificationsStatus(id){
    if(scope.edit.notifications === 'on'){
        var uid = firebase.auth().currentUser.uid;
        firebase.database().ref("private/" + uid + '/stopNotifications/' + id).remove();
    } else {
        var uid = firebase.auth().currentUser.uid;
        firebase.database().ref("private/" + uid + '/stopNotifications/' + id).set({val: 1});
    }
}

function imageURLChange(){
    scope.edit.files.coverImage = '';
    scope.edit.coverImage = scope.edit.postContent.imageURL;
}

function deleteContent(){
    scope.index.delete = {
        what: scope.index.page.urlVars.page.toLowerCase(),
        loading: false,
        vars: {
            id: scope.index.page.urlVars.id + '',
            channel: scope.index.editSelections.channel + ''
        },
        func: deleteContent
    }

    function deleteContent(){
        if(!scope.index.delete.loading){
            scope.index.delete.loading = true;

            firebase.database().ref('public/' + scope.index.delete.what + 's/' + scope.index.delete.vars.id).remove().then(function(){
                if(scope.index.delete.what === 'post'){
                    changeURL('/channel/' + scope.index.delete.vars.channel + '/posts');
                }

                if(scope.index.delete.what === 'collection'){
                    changeURL('/channel/' + scope.index.delete.vars.channel + '/collections');
                }

                if(scope.index.delete.what === 'channel'){
                    changeURL('/dashboard/mychannels');
                }
                
                scope.index.fadePopUp('out');
            });
        }
    }

    scope.index.fadePopUp('in', 'delete');
}
