function initExploreContent(){
    if(scope.index.page.urlVars.isCategories){
        if(scope.categories === undefined){
            initCategoriesContent();
        }
        function loadCategoriesList(){
            if(scope.categories.list.length === 0){
                setTimeout(loadCategoriesList, 50);
            } else {
                if(scope.categories.list.indexOf(scope.index.page.urlVars.title.toLowerCase()) !== -1){
                    continueExplore();
                } else {
                    changeURL('/404');
                }
            }
        }
        loadCategoriesList();
    } else {
        continueExplore();
    }

    function continueExplore(){
        scope.explore = {
            getExplorePosts: getExplorePosts
        }
        scope.$applyAsync();
    
        getExplorePosts(true);
    }
}

function getExplorePosts(firstTime){
    if(!scope.index.retrievingData || firstTime){
        var ref;
        var urlVars = scope.index.page.urlVars;
        var filter = '';
        scope.index.retrievingData = true;

        if(firstTime){
            window.scrollTo(0, 0);
            scope.index.posts = [];
            scope.index.postsEnd = false;

            if(urlVars.isCategories){
                if(urlVars.filter === 'new'){
                    filter = 'category_new';
                    ref = firebase.database().ref('/public/posts').orderByChild('values/category_new').startAt(urlVars.title).endAt(urlVars.title + "\uf8ff").limitToLast(local.postsRetrieved);
                } else {
                    filter = 'category_hot'; 
                    ref = firebase.database().ref('/public/posts').orderByChild('values/category_hot').startAt(urlVars.title).endAt(urlVars.title + "\uf8ff").limitToLast(local.postsRetrieved);
                }
            } else {
                if(['HOT','TRENDY','NEW'].indexOf(urlVars.title) !== -1){
                    filter = 'rating'; 
                    ref = firebase.database().ref('/public/posts').orderByChild('values/rating').startAt((['NEW','TRENDY','HOT'].indexOf(urlVars.title) + 1) + '-').endAt((['NEW','TRENDY','HOT'].indexOf(urlVars.title) + 1) + "-\uf8ff").limitToLast(local.postsRetrieved);
                } else {
                    if(urlVars.filter === 'new'){
                        filter = 'type_new'; 
                        ref = firebase.database().ref('/public/posts').orderByChild('values/type_new').startAt(urlVars.title).endAt(urlVars.title + "\uf8ff").limitToLast(local.postsRetrieved);
                    } else {
                        filter = 'type_hot'; 
                        ref = firebase.database().ref('/public/posts').orderByChild('values/type_hot').startAt(urlVars.title).endAt(urlVars.title + "\uf8ff").limitToLast(local.postsRetrieved);
                    }
                }
            }
        } else {
            if(urlVars.isCategories){
                if(urlVars.filter === 'new'){
                    filter = 'category_new'; 
                    ref = firebase.database().ref('/public/posts').orderByChild('values/category_new').startAt(urlVars.title).endAt(scope.index.endAt).limitToLast(local.postsRetrieved);
                } else {
                    filter = 'category_hot'; 
                    ref = firebase.database().ref('/public/posts').orderByChild('values/category_hot').startAt(urlVars.title).endAt(scope.index.endAt).limitToLast(local.postsRetrieved);
                }
            } else {
                if(['NEW','TRENDY','HOT'].indexOf(urlVars.title) !== -1){
                    filter = 'rating'; 
                    ref = firebase.database().ref('/public/posts').orderByChild('values/rating').startAt((['NEW','TRENDY','HOT'].indexOf(urlVars.title) + 1) + '-').endAt(scope.index.endAt).limitToLast(local.postsRetrieved);
                } else {
                    if(urlVars.filter === 'new'){
                        filter = 'type_new'; 
                        ref = firebase.database().ref('/public/posts').orderByChild('values/type_new').startAt(urlVars.title).endAt(scope.index.endAt).limitToLast(local.postsRetrieved);
                    } else {
                        filter = 'type_hot'; 
                        ref = firebase.database().ref('/public/posts').orderByChild('values/type_hot').startAt(urlVars.title).endAt(scope.index.endAt).limitToLast(local.postsRetrieved);
                    }
                }
            }
        }

        ref.once("value").then(function(snapshot){
            var obj = snapshot.val();
            var array = [];
            var resultArray = [];
            if(obj !== null){
                array = Object.keys(snapshot.val());
                function compare(a,b){
                    if(obj[a]['values'][filter] < obj[b]['values'][filter]){
                        return -1;
                    }
                    if(obj[a]['values'][filter] > obj[b]['values'][filter]){
                        return 1;
                    }
                    return 0;
                }
                array.sort(compare);
                if(!firstTime){
                    array.pop();
                }
                array.forEach(function(item){
                    resultArray.push(obj[item]);
                    resultArray[resultArray.length - 1].id = item;
                });

                if(array.length>0){
                    scope.index.endAt = obj[array[0]]['values'][filter];
                }

                displayPosts(resultArray, firstTime);
            } else {
                displayPosts(null);
            }
        });
    }
}
