function initChannelContent(){
    scope.channel.loading= true;
    scope.channel.getAHrefURLExternal = getAHrefURLExternal;
    scope.channel.addCollection = addCollection;
    scope.channel.addPost = addPost;

    scope.channel.collections = [];
    scope.channel.loadContent = true;
    scope.channel.collection = {};
    scope.channel.post = {};
    scope.channel.posts = [];
    scope.channel.collectionName = '';
    
    scope.channel.subscribeClick = subscribeClick;
    scope.channel.getPostsCollection = getPostsCollection;

    scope.channel.filter = 'new';
    scope.channel.arrangeCollections = arrangeCollections;
    scope.channel.getPostsChannel = getPostsChannel;

    scope.channel.recommendChannel = recommendChannel;

    /* for post comments */
    scope.channel.comment = {
        channels:[],
        index: '',
        text: '',
        error: false,
        inProgress: false,

        comments: [],
        commentsEnd: false,
        retrievingData: false,

        edit: '',
        textEdit: ''
    }

    scope.channel.postComment = postComment;
    scope.channel.getPostComments = getPostComments;
    scope.channel.followComment = followComment;
    scope.channel.saveComment = saveComment;
    scope.channel.deleteComment = deleteComment;
    scope.channel.likeComment = likeComment;
    scope.channel.getReplays = getReplays;
    scope.channel.createReplay = createReplay;
    scope.channel.saveReplay = saveReplay;
    scope.channel.deleteReplay = deleteReplay;
    scope.channel.likeReplay = likeReplay;
    scope.channel.followReplay = followReplay;

    scope.channel.pushRecommendation = pushRecommendation;
    scope.channel.removeRecommendation = removeRecommendation;
    /* end for post comments */

    if(scope.index.page.urlVars.page === 'COLLECTION' || scope.index.page.urlVars.page === 'POST'){
        scope.index.retrievingData = true;
        if(scope.index.page.urlVars.page === 'COLLECTION'){
            firebase.database().ref("public/collections/" + scope.index.page.urlVars.partId).once("value").then(function(snapshot) {
                if(snapshot.val() !== null){
                    scope.index.page.urlVars.id = snapshot.val().channel;
                    scope.channel.collection = snapshot.val();
                    getPostsCollection();
                    contentChannelIdentity();
                } else {
                    changeURL('/404');
                }
            });
        } else {
            firebase.database().ref("public/posts").orderByKey().equalTo(scope.index.page.urlVars.partId).once("value").then(function(snapshot) {
                if(snapshot.val() !== null){
                    scope.channel.loadContent = false;
                    var array = Object.keys(snapshot.val());
                    var resultArray = [];
                    array.forEach(function(item){
                        resultArray.push(snapshot.val()[item]);
                        resultArray[resultArray.length - 1].id = item;
                    });
                    displayPosts(resultArray, true);

                    scope.index.page.urlVars.id = snapshot.val()[array[0]].channel;
                    firebase.database().ref("public/collections/" + snapshot.val()[array[0]].content.collection).once("value").then(function(snapshot) {
                        if(snapshot.val() !== null){
                            scope.channel.collectionName = snapshot.val().content.name;
                            scope.$applyAsync();
                        }
                    });
                    contentChannelIdentity();

                    getPostComments(true);
                } else {
                    changeURL('/404');
                }
            });

            if(firebase.auth().currentUser){
                function checkUserLoaded(){
                    if(scope.index.user.settings){
                        var array = Object.keys(scope.index.user.channels);
                        array.forEach(function(item){
                            scope.channel.comment.channels.push(item);
                        });
                        if(array.length >= 1){
                            scope.channel.comment.index = 0;
                        }
                    } else {
                        setTimeout(checkUserLoaded, 50);
                    }
                }
                checkUserLoaded();
            }
        }
    } else {
        //get channel data( identity + about)
        contentChannelIdentity();
        if(scope.index.page.urlVars.page === 'ABOUT'){
            if(scope.channel.values.values !== undefined){
                scope.channel.loadContent = true;
                firebase.database().ref("public/channels/" + scope.index.page.urlVars.id + '/values/likes').once("value").then(function(snapshot) {
                    scope.channel.values.values.likes = snapshot.val();
                    scope.channel.loadContent = false;
                    scope.$applyAsync();
                });
            } else {
                scope.channel.loadContent = false;
                scope.$applyAsync();
            }
        }

        if(scope.index.page.urlVars.page === 'CHANNELS'){
            scope.index.channels = [];
            scope.index.channelsEnd = false;
            scope.index.retrievingData = true;
            scope.channel.loadContent = false;

            scope.channel.editChannels = false;
            scope.$applyAsync();

            function recommendationsContinue(){
                if(scope.channel.values.chId){
                    var r = scope.channel.values.about.recommendations;
                    var obj = {};
                    var count = 0;
                    if(r !== null && r !== undefined){
                        var array = Object.keys(r);
                        array.forEach(function(item){
                            firebase.database().ref('/public/channels/' + item).once('value').then(function(snapshot){
                                if(snapshot.val() !== null){
                                    obj[item] = snapshot.val();
                                } else {
                                    if(isMine(scope.channel.values.chId)){
                                        firebase.database().ref('/public/channels/' + scope.channel.values.chId + '/about/recommendations/' + item).remove();
                                    }
                                }
                                count++;
                                if(count === array.length){
                                    displayChannels(obj, true);
                                }
                            });
                        });
                    } else {
                        displayChannels(null, true);
                    }
                } else {
                    setTimeout(recommendationsContinue, 50);
                }
            }
            recommendationsContinue();
        }

        //get page data (posts, collections, channels)
        if(scope.index.page.urlVars.page === 'COLLECTIONS'){
            scope.channel.collections = [];
            scope.$applyAsync();
            scope.index.retrievingData = true;
            firebase.database().ref("public/collections/").orderByChild('channel').equalTo(scope.index.page.urlVars.id).once("value").then(function(snapshot) {
                if(snapshot.val() !== null){
                    var array = Object.keys(snapshot.val());
                    array.forEach(function(item){
                        obj = snapshot.val()[item];
                        obj.id = item;
                        scope.channel.collections.unshift(obj);
                    });
                }
                scope.channel.loadContent = false;
                scope.index.retrievingData = false;
                scope.$applyAsync();
            });
        }


        
        if(scope.index.page.urlVars.page === 'POSTS'){
            getPostsChannel(true);
            scope.channel.loadContent = false;
            scope.$applyAsync();
        }

        if(scope.index.page.urlVars.page === 'CHANNELS'){
            scope.channel.loadContent = false;
            scope.$applyAsync();
        }
    }
}

function contentChannelIdentity(){
    if(!local.channelMenuClick){
        scope.channel.values.subscribed = '';
        scope.$applyAsync();

        firebase.database().ref("public/channels/" + scope.index.page.urlVars.id).once("value").then(function(snapshot) {
            if(snapshot.val() !== null){
                scope.channel.values = snapshot.val();
                scope.channel.values.chId = scope.index.page.urlVars.id;

                scope.channel.loading = false;
                scope.$applyAsync();
            } else {
                changeURL('/404');
            }
        });

        if(firebase.auth().currentUser !== null){
            var uid = firebase.auth().currentUser.uid;
            firebase.database().ref('private/' + uid + '/subscribed/' + scope.index.page.urlVars.id).once('value').then(function(snapshot){
                if(snapshot.val() === null || snapshot.val().state === 'off'){
                    scope.channel.values.subscribed = false;
                } else {
                    scope.channel.values.subscribed = true;
                }
                scope.$applyAsync();
            });
        } else {
            scope.channel.values.subscribed = false;
            scope.$applyAsync();
        }
    } else {
        scope.channel.loading = false;
        scope.$applyAsync();
    }
}

function getAHrefURLExternal(url){
    if(url.substring(0,7) === 'http://' || url.substring(0,8) === 'https://'){
        return url;
    }
    return 'http://' + url;
}

function addCollection(){
    scope.index.editSelections = {
        channel: scope.index.page.urlVars.id,
        collection: ''
    }

    changeURL('/edit/collection');
}

function addPost(){
    scope.index.editSelections = {
        channel: scope.index.page.urlVars.id,
        collection: scope.index.page.urlVars.partId ? scope.index.page.urlVars.partId : ''
    }

    changeURL('/edit/post');
}

function getPostsCollection(nextPosts){
    if(!scope.index.retrievingData || !nextPosts){
        scope.index.retrievingData = true;
        if(!nextPosts){
            firebase.database().ref("public/posts/").orderByChild('/values/collection').startAt(scope.index.page.urlVars.partId).endAt(scope.index.page.urlVars.partId + "\uf8ff").limitToLast(local.postsRetrieved).once("value").then(function(snapshot) {
                var obj = snapshot.val();
                var resultArray = [];
                if(obj !== null){
                    var array = Object.keys(snapshot.val());
                    function compare(a,b){
                        if(obj[a].values.collection < obj[b].values.collection){
                            return -1;
                        }
                        if(obj[a].values.collection > obj[b].values.collection){
                            return 1;
                        }
                        return 0;
                    }
                    array.sort(compare);
                    array.forEach(function(item){
                        resultArray.push(obj[item]);
                        resultArray[resultArray.length - 1].id = item;
                    });
                    scope.index.endAt = snapshot.val()[array[0]].values.collection;
                }
                scope.channel.loadContent = false;
                displayPosts(resultArray, true);
            });
        } else {
            firebase.database().ref("public/posts/").orderByChild('/values/collection').startAt(scope.index.page.urlVars.partId).endAt(scope.index.endAt).limitToLast(local.postsRetrieved).once("value").then(function(snapshot) {
                var obj = snapshot.val();
                var resultArray = [];
                if(obj !== null){
                    var array = Object.keys(snapshot.val());
                    function compare(a,b){
                        if(obj[a].values.collection < obj[b].values.collection){
                            return -1;
                        }
                        if(obj[a].values.collection > obj[b].values.collection){
                            return 1;
                        }
                        return 0;
                    }
                    array.sort(compare);
                    array.pop();
                    
                    array.forEach(function(item){
                        resultArray.push(obj[item]);
                        resultArray[resultArray.length - 1].id = item;
                    });
                    if(array.length>0){
                        scope.index.endAt = obj[array[0]].values.collection;
                    }
                }
                displayPosts(resultArray);
            });
        }
    }
}

function getPostsChannel(firstTime){
    if(!scope.index.retrievingData || firstTime){
        var ref;
        var urlVars = scope.index.page.urlVars;
        var filter = '';
        scope.index.retrievingData = true;

        if(firstTime){
            window.scrollTo(0, 0);
            scope.index.posts = [];
            scope.index.postsEnd = false;

            if(scope.channel.filter === 'new'){
                filter = 'channel_new';
                ref = firebase.database().ref('/public/posts').orderByChild('values/channel_new').startAt(urlVars.id + '--/-//-').endAt(urlVars.id + '--/-//-' + "\uf8ff").limitToLast(local.postsRetrieved);
            } else {
                filter = 'channel_hot'; 
                ref = firebase.database().ref('/public/posts').orderByChild('values/channel_hot').startAt(urlVars.id + '--/-//-').endAt(urlVars.id + '--/-//-' + "\uf8ff").limitToLast(local.postsRetrieved);
            }
        } else {
            if(scope.channel.filter === 'new'){
                filter = 'channel_new';
                ref = firebase.database().ref('/public/posts').orderByChild('values/channel_new').startAt(urlVars.id + '--/-//-').endAt(scope.index.endAt).limitToLast(local.postsRetrieved);
            } else {
                filter = 'channel_hot'; 
                ref = firebase.database().ref('/public/posts').orderByChild('values/channel_hot').startAt(urlVars.id + '--/-//-').endAt(scope.index.endAt).limitToLast(local.postsRetrieved);
            }
        }

        ref.once("value").then(function(snapshot){
            var obj = snapshot.val();
            var array = [];
            var resultArray = [];
            if(obj !== null){
                array = Object.keys(snapshot.val());
                function compare(a,b){
                    if(obj[a]['values'][filter] < obj[b]['values'][filter]){
                        return -1;
                    }
                    if(obj[a]['values'][filter] > obj[b]['values'][filter]){
                        return 1;
                    }
                    return 0;
                }
                array.sort(compare);
                if(!firstTime){
                    array.pop();
                }
                array.forEach(function(item){
                    resultArray.push(obj[item]);
                    resultArray[resultArray.length - 1].id = item;
                });

                if(array.length>0){
                    scope.index.endAt = obj[array[0]]['values'][filter];
                }

                displayPosts(resultArray, firstTime);
            } else {
                displayPosts();
            }
        });
    }
}

function subscribeClick(){
    if(scope.channel.values.subscribed !== ''){
        if(firebase.auth().currentUser !== null){
            var uid = firebase.auth().currentUser.uid;
            if(scope.channel.values.subscribed){
                //unsubscribe
                scope.channel.values.subscribed = '';
                firebase.database().ref('private/' + uid + '/subscribed/' + scope.index.page.urlVars.id).update({state:'off'}).then(function(){
                    scope.channel.values.subscribed = false;
                    scope.channel.values.values.subscribers--;
                    scope.$applyAsync();
                });
            } else {
                //subscribe
                scope.channel.values.subscribed = '';
                firebase.database().ref('private/' + uid + '/subscribed/' + scope.index.page.urlVars.id).set({state:'on'}).then(function(){
                    scope.channel.values.subscribed = true;
                    scope.channel.values.values.subscribers++;
                    scope.$applyAsync();
                });
            }
        } else {
            scope.index.fadePopUp('in', 'Sign In');
        }
    }
}

function arrangeCollections(){
    var compare;
    if(scope.channel.filter === 'new'){
        compare = function(a, b){
            if(a.id > b.id){
                return -1;
            }
            if(a.id < b.id){
                return 1;
            }
            return 0;
        }
    } else {
        compare = function(a, b){
            if(a.content.nameSearch < b.content.nameSearch){
                return -1;
            }
            if(a.content.nameSearch > b.content.nameSearch){
                return 1;
            }
            return 0;
        }
    }

    scope.channel.collections.sort(compare);
    scope.$applyAsync();
}

function postComment(){
    if(!scope.channel.comment.inProgress && scope.channel.comment.text !== ''){
        if(firebase.auth().currentUser){
            scope.channel.comment.inProgress = true;
            if(scope.channel.comment.index !== ''){
                var uid = firebase.auth().currentUser.uid;
                var followersUids = {}
                followersUids[uid] = {val:1};
                var key = firebase.database().ref('public/comments/').push({
                    type: 'comment',
                    for: scope.index.page.urlVars.partId,
                    from: scope.channel.comment.channels[scope.channel.comment.index],
                    text: scope.channel.comment.text,
                    uid: uid,
                    followers:{
                        uids:followersUids
                    }
                }).key;
                
                function continueComent(){
                    if(key){
                        firebase.database().ref('public/comments/' + key + '/values').set({
                            likes: 0,
                            replays: 0,
                            comment_new: scope.index.page.urlVars.partId + key,
                            comment_hot: scope.index.page.urlVars.partId + '0' + key
                        }).then(function(){
                            /* adding comment to the list */
                            var followersUids = {}
                            followersUids[uid] = {val:1};
                            var comm = {
                                type: 'comment',
                                for: scope.index.page.urlVars.partId,
                                from: scope.channel.comment.channels[scope.channel.comment.index],
                                text: scope.channel.comment.text,
                                uid: uid,
                                followers:{
                                    uids:followersUids
                                },
                                id: key,
                                channelInfo: {
                                    name: scope.index.user.channels[scope.channel.comment.channels[scope.channel.comment.index]].name,
                                    profilePic: scope.index.user.channels[scope.channel.comment.channels[scope.channel.comment.index]].profilePic
                                },
                                actions: {
                                    like: false,
                                    follow: true,
                                },
                                values:{
                                    likes: 0,
                                    replays: 0,
                                }
                            }
                            scope.channel.comment.comments.unshift(comm);
                            /* end */
                            scope.channel.comment.text = '';
                            scope.channel.comment.inProgress = false;

                            scope.index.posts[0].values.comments += 1;

                            scope.$applyAsync();
                        });
                    } else {
                        setTimeout(continueComent, 50);
                    }
                }
                continueComent();
            } else {
                scope.channel.comment.inProgress = false;
                scope.channel.comment.error = true;
            }

            console.log(scope.channel.comment);
        } else {
            scope.index.fadePopUp('in', 'Sign In');
        }
    }
}

function getPostComments(firstTime){
    if(!scope.channel.comment.retrievingData){
        var ref;
        var urlVars = scope.index.page.urlVars;
        var filter = '';
        scope.channel.comment.retrievingData = true;
        var notificationsComment = '';
        if(firstTime){
            if(scope.channel.filter === 'new'){
                filter = 'comment_new';
                ref = firebase.database().ref('/public/comments').orderByChild('values/comment_new').startAt(urlVars.partId).endAt(urlVars.partId + "\uf8ff").limitToLast(local.postsRetrieved);
            } else {
                filter = 'comment_hot'; 
                ref = firebase.database().ref('/public/comments').orderByChild('values/comment_hot').startAt(urlVars.partId).endAt(urlVars.partId + "\uf8ff").limitToLast(local.postsRetrieved);
            }

            if(scope.index.page.urlVars.comment !== undefined){
                var commId = scope.index.page.urlVars.comment + '';
                firebase.database().ref('/public/comments/' + scope.index.page.urlVars.comment).once('value').then(function(snapshot){
                    if(snapshot.val() !== null){
                        notificationsComment = snapshot.val();
                        notificationsComment.id = commId;
                        notificationsComment.newNotificationComment = true;
                    } else {
                        notificationsComment = false;
                    }
                });
                scope.index.page.urlVars.comment = undefined;
                window.history.replaceState(null, null, "../../post/" + scope.index.page.urlVars.partId);
            } else {
                var notificationsComment = false;
            }
        } else {
            if(scope.channel.filter === 'new'){
                filter = 'comment_new';
                ref = firebase.database().ref('/public/comments').orderByChild('values/comment_new').startAt(urlVars.partId).endAt(scope.index.endAt).limitToLast(local.postsRetrieved);
            } else {
                filter = 'comment_hot'; 
                ref = firebase.database().ref('/public/comments').orderByChild('values/comment_hot').startAt(urlVars.partId).endAt(scope.index.endAt).limitToLast(local.postsRetrieved);
            }
        }

        ref.once("value").then(function(snapshot){
            var obj = snapshot.val();
            var array = [];
            var resultArray = [];
            if(obj !== null){
                array = Object.keys(obj);
                function compare(a,b){
                    if(obj[a]['values'][filter] < obj[b]['values'][filter]){
                        return -1;
                    }
                    if(obj[a]['values'][filter] > obj[b]['values'][filter]){
                        return 1;
                    }
                    return 0;
                }
                array.sort(compare);

                if(!firstTime){
                    array.pop();
                } else {
                    local.iteration++;
                    scope.channel.comment.comments = [];
                    scope.channel.comment.commentsEnd = false;
                }

                array.forEach(function(item){
                    resultArray.push(obj[item]);
                    resultArray[resultArray.length - 1].id = item;
                });

                if(array.length>0){
                    scope.index.endAt = obj[array[0]]['values'][filter];
                }


                if(array.length < local.postsRetrieved && firstTime){
                    scope.channel.comment.commentsEnd = true;
                }

                if(array.length < local.postsRetrieved - 1 && !firstTime){
                    scope.channel.comment.commentsEnd = true;
                }

                resultArray.reverse();

                function notificationComm(){
                    if(notificationsComment !== ''){
                        if(notificationsComment !== false){
                            resultArray.unshift(notificationsComment);
                        }
                        resultArray.forEach(function(item){
                            item.channelInfo = {
                                name: '',
                                profilePic: ''
                            };
                
                            item.actions = {
                                like: '',
                                follow: false,
                            }
        
                            scope.channel.comment.comments.push(item);
        
                            getCommentChannel(scope.channel.comment.comments, scope.channel.comment.comments.length - 1, parseInt(local.iteration + ' '));
                            getCommentActions(scope.channel.comment.comments, scope.channel.comment.comments.length - 1, parseInt(local.iteration + ' '));
                        });
                        scope.channel.comment.retrievingData = false;
                        scope.$applyAsync();
                    } else {
                        setTimeout(notificationComm, 30);
                    }
                }
                notificationComm();
            } else {
                scope.channel.comment.commentsEnd = true;
                scope.channel.comment.retrievingData = false;
                local.iteration++;
                scope.$applyAsync();
            }
        });
    }
}

function getCommentChannel(array, index, iteration){ 
    if(iteration === local.iteration){
        firebase.database().ref('public/channels/' + array[index].from + '/identity').once('value').then(function(snapshot){
            if(iteration === local.iteration && snapshot.val() !== null){
                array[index].channelInfo = {
                    name: snapshot.val().name,
                    profilePic: snapshot.val().profilePic
                }
                scope.$applyAsync();
            }
        });
    }
}

function getCommentActions(array, index, iteration){
    if(iteration === local.iteration){
        if(firebase.auth().currentUser){
            var uid = firebase.auth().currentUser.uid;
            firebase.database().ref('private/' + uid + '/likes/' + array[index].id).once('value').then(function(snapshot){
                if(iteration === local.iteration){
                    if(snapshot.val() && snapshot.val().state === 'on'){
                        array[index].actions.like = true;
                    } else {
                        array[index].actions.like = false;
                    }
                }
                scope.$applyAsync();
            });

            if(array[index].followers && array[index].followers.uids && array[index].followers.uids[uid]){
                array[index].actions.follow = true;
            }

            if(array[index].type === 'replay' && array[index].uid === uid){
                firebase.database().ref('private/' + uid + '/stopNotifications/' + array[index].id).once('value').then(function(snapshot){
                    if(iteration === local.iteration){
                        if(snapshot.val()){
                            array[index].actions.follow = false;
                        } else {
                            array[index].actions.follow = true;
                        }
                    }
                    scope.$applyAsync();
                });
            }
        } else {
            array[index].actions.like = false;
            scope.$applyAsync();
        }
    }
}

function followComment(index){
    var comment = scope.channel.comment.comments[index];
    if(firebase.auth().currentUser){
        var uid = firebase.auth().currentUser.uid;
        if(comment.actions.follow){
            //unfollow
            firebase.database().ref('private/' + uid + '/stopNotifications/' + comment.id).set({val:1});
            firebase.database().ref('public/comments/' + comment.id + '/followers/uids/' + uid).remove();
            comment.actions.follow = false;
        } else {
            //follow
            firebase.database().ref('private/' + uid + '/stopNotifications/' + comment.id).remove();
            firebase.database().ref('public/comments/' + comment.id + '/followers/uids/' + uid).set({val:1});
            comment.actions.follow = true;
        }
        scope.$applyAsync();
    } else {
        scope.index.fadePopUp('in', 'Sign In');
    }
}

function followReplay(parentIndex, index){
    var index2 = scope.channel.comment.comments[parentIndex].replay.replays.length - 1 - index;
    var comment = scope.channel.comment.comments[parentIndex].replay.replays[index2];
    if(firebase.auth().currentUser){
        var uid = firebase.auth().currentUser.uid;
        if(comment.actions.follow){
            //unfollow
            firebase.database().ref('private/' + uid + '/stopNotifications/' + comment.id).set({val:1});
            comment.actions.follow = false;
        } else {
            //follow
            firebase.database().ref('private/' + uid + '/stopNotifications/' + comment.id).remove();
            comment.actions.follow = true;
        }
        scope.$applyAsync();
    } else {
        scope.index.fadePopUp('in', 'Sign In');
    }
}

function saveComment(index){
    if(scope.channel.comment.textEdit !== ''){
        var comment = scope.channel.comment.comments[index];
        firebase.database().ref('public/comments/' + comment.id + '/text').set(scope.channel.comment.textEdit);
        comment.text = scope.channel.comment.textEdit + ' ';
        scope.channel.comment.edit = '';
        scope.$applyAsync();
    }
}

function deleteComment(index){
    scope.index.delete = {
        what: 'comment',
        loading: false,
        vars: {
            index: index
        },
        func: deleteCommentComent
    }

    function deleteCommentComent(){
        if(scope.index.delete.loading === false){
            var comment = scope.channel.comment.comments[scope.index.delete.vars.index];
            scope.index.delete.loading = true;

            firebase.database().ref('public/comments/' + comment.id).remove().then(function(){
                scope.index.delete.loading = false;
                scope.index.posts[0].values.comments--;
                scope.channel.comment.comments.splice(index, 1);

                scope.$applyAsync();
                scope.index.fadePopUp('out');
            });
        }
    }

    scope.index.fadePopUp('in', 'delete');
}

function likeComment(index){
    if(firebase.auth().currentUser){
        var comment = scope.channel.comment.comments[index];
        var bool = comment.actions.like;
        
        var uid = firebase.auth().currentUser.uid;
        if(bool){
            //unlike
            firebase.database().ref('private/' + uid + '/likes/' + comment.id).update({
                state:'off',
                type:'comment'
            });
            comment.actions.like = false;
            comment.values.likes--;
            scope.$applyAsync();
        } else {
            //like
            firebase.database().ref('private/' + uid + '/likes/' + comment.id).set({
                state:'on',
                type:'comment'
            });
            comment.actions.like = true;
            comment.values.likes++;
            scope.$applyAsync();
        }
    } else {
        scope.index.fadePopUp('in', 'Sign In');
    }
}

function getReplays(index, firstTime){
    var comment = scope.channel.comment.comments[index];
    if(!comment.replay || comment.replay.open === false || !firstTime ){
        if(firstTime){
            local.replaisRetrieved = 7;
            comment.replay = {
                open: true,
                text: '',
                editText: '',
                error: false,
                indexChannel: scope.channel.comment.index + '',
                inProgress: false,

                replays: [],
                replaysEnd: false,

                retrievingData: false,
            };
        } else {
            local.replaisRetrieved = 10;
        }

        if(!comment.replay.retrievingData){
            var ref;
            var urlVars = scope.index.page.urlVars;
            comment.replay.retrievingData = true;

            if(firstTime){
                ref = firebase.database().ref('/public/comments').orderByChild('values/replay').startAt(comment.id).endAt(comment.id + "\uf8ff").limitToLast(local.replaisRetrieved);
            } else {
                ref = firebase.database().ref('/public/comments').orderByChild('values/replay').startAt(comment.id).endAt(scope.index.endAt).limitToLast(local.replaisRetrieved);
            }
    
            ref.once("value").then(function(snapshot){
                var obj = snapshot.val();
                var array = [];
                var resultArray = [];
                if(obj !== null){
                    array = Object.keys(obj);
                    function compare(a,b){
                        if(obj[a]['values']['replay'] < obj[b]['values']['replay']){
                            return -1;
                        }
                        if(obj[a]['values']['replay'] > obj[b]['values']['replay']){
                            return 1;
                        }
                        return 0;
                    }
                    array.sort(compare);
    
                    if(!firstTime){
                        array.pop();
                    } else {
                        local.iteration++;
                    }
    
                    array.forEach(function(item){
                        resultArray.push(obj[item]);
                        resultArray[resultArray.length - 1].id = item;
                    });
    
                    if(array.length>0){
                        scope.index.endAt = obj[array[0]]['values']['replay'];
                    }
    
    
                    if(array.length < local.replaisRetrieved && firstTime){
                        comment.replay.replaysEnd = true;
                    }
    
                    if(array.length < local.replaisRetrieved - 1 && !firstTime){
                        comment.replay.replaysEnd = true;
                    }

                    resultArray.reverse();
    
                    resultArray.forEach(function(item){
                        item.channelInfo = {
                            name: '',
                            profilePic: ''
                        };
            
                        item.actions = {
                            like: '',
                            follow: false,
                        }
    
                        comment.replay.replays.push(item);
                        getCommentChannel(comment.replay.replays, comment.replay.replays.length - 1, parseInt(local.iteration + ' '));
                        getCommentActions(comment.replay.replays, comment.replay.replays.length - 1, parseInt(local.iteration + ' '));
                    });
                    comment.replay.retrievingData = false;
                    scope.$applyAsync();
                } else {
                    comment.replay.replaysEnd = true;
                    comment.replay.retrievingData = false;
                    local.iteration++;
                    scope.$applyAsync();
                }
            });
        }
    } else {
        comment.replay.open = false;
    }
}

function createReplay(index){
    var comment = scope.channel.comment.comments[index];
    if(!comment.replay.inProgress && comment.replay.text !== ''){
        if(firebase.auth().currentUser){
            comment.replay.inProgress = true;
            if(comment.replay.indexChannel !== ''){
                var uid = firebase.auth().currentUser.uid;

                firebase.database().ref('public/comments/' + comment.id + '/followers/uids/' + uid).set({val:1}).then(function(){
                    var key = firebase.database().ref('public/comments/').push({
                        type: 'replay',
                        for: scope.index.page.urlVars.partId,
                        from: scope.channel.comment.channels[comment.replay.indexChannel],
                        text: comment.replay.text,
                        uid: uid,
                        parentCommentId: comment.id
                    }).key;

                    function continueComent(){
                        if(key){
                            firebase.database().ref('public/comments/' + key + '/values').set({
                                likes: 0,
                                replay: comment.id + key,
                            }).then(function(){
                                /* adding comment to the list */
                                var comm = {
                                    type: 'replay',
                                    for: scope.index.page.urlVars.partId,
                                    from: scope.channel.comment.channels[comment.replay.indexChannel],
                                    text: comment.replay.text,
                                    uid: uid,
                                    parentCommentId: comment.id,
                                    id: key,
                                    channelInfo: {
                                        name: scope.index.user.channels[scope.channel.comment.channels[comment.replay.indexChannel]].name,
                                        profilePic: scope.index.user.channels[scope.channel.comment.channels[comment.replay.indexChannel]].profilePic
                                    },
                                    actions: {
                                        like: false
                                    },
                                    values:{
                                        likes: 0,
                                    }
                                }
                                comment.replay.replays.unshift(comm);
                                /* end */
                                comment.replay.text = '';
                                comment.replay.inProgress = false;
                                comment.values.replays += 1;
    
                                scope.$applyAsync();
                            });
                        } else {
                            setTimeout(continueComent, 50);
                        }
                    }
                    continueComent();
                });
            } else {
                comment.replay.inProgress = false;
                comment.replay.error = true;
            }
        } else {
            scope.index.fadePopUp('in', 'Sign In');
        }
    }
}


function saveReplay(parentIndex, index){
    if(scope.channel.comment.textEdit !== ''){
        var index2 = scope.channel.comment.comments[parentIndex].replay.replays.length - 1 - index;
        var comment = scope.channel.comment.comments[parentIndex].replay.replays[index2];
        firebase.database().ref('public/comments/' + comment.id + '/text').set(scope.channel.comment.textEdit);
        comment.text = scope.channel.comment.textEdit + ' ';
        scope.channel.comment.edit = '';
        scope.$applyAsync();
    }
}

function deleteReplay(parentIndex, index){
    scope.index.delete = {
        what: 'comment',
        loading: false,
        vars: {
            parentIndex: parentIndex,
            index: index
        },
        func: deleteReplayComent
    }

    function deleteReplayComent(){
        if(scope.index.delete.loading === false){
            var index2 = scope.channel.comment.comments[scope.index.delete.vars.parentIndex].replay.replays.length - 1 - scope.index.delete.vars.index;
            var comment = scope.channel.comment.comments[scope.index.delete.vars.parentIndex].replay.replays[index2];

            scope.index.delete.loading = true;
            
            firebase.database().ref('public/comments/' + comment.id).remove().then(function(){
                scope.index.delete.loading = false;
                scope.channel.comment.comments[scope.index.delete.vars.parentIndex].values.replays--;
                scope.channel.comment.comments[scope.index.delete.vars.parentIndex].replay.replays.splice(index2, 1);

                scope.$applyAsync();
                scope.index.fadePopUp('out');
            });
        }
    }

    scope.index.fadePopUp('in', 'delete');
}

function likeReplay(parentIndex, index){
    if(firebase.auth().currentUser){
        var index2 = scope.channel.comment.comments[parentIndex].replay.replays.length - 1 - index;
        var comment = scope.channel.comment.comments[parentIndex].replay.replays[index2];
        var bool = comment.actions.like;
        
        var uid = firebase.auth().currentUser.uid;
        if(bool){
            //unlike
            firebase.database().ref('private/' + uid + '/likes/' + comment.id).update({
                state:'off',
                type:'replay'
            });
            comment.actions.like = false;
            comment.values.likes--;
            scope.$applyAsync();
        } else {
            //like
            firebase.database().ref('private/' + uid + '/likes/' + comment.id).set({
                state:'on',
                type:'replay'
            });
            comment.actions.like = true;
            comment.values.likes++;
            scope.$applyAsync();
        }
    } else {
        scope.index.fadePopUp('in', 'Sign In');
    }
}

function recommendChannel(){
    if(firebase.auth().currentUser){
        var uid = firebase.auth().currentUser.uid;
        scope.index.fadePopUp('in', 'recommendation')
        function userSettings(){
            if(scope.index.user.settings !== undefined){
                scope.channel.recommend = {
                    loading: false,
                    channels: scope.index.user.channels ? Object.keys(scope.index.user.channels) : []
                }
            } else {
                setTimeout(userSettings, 50);
            }
        }
        userSettings();
    } else {
        scope.index.fadePopUp('in', 'Sign In');
    }
}

function pushRecommendation(index){
    scope.channel.recommend.loading = true;
    function recommendContinue(){
        if(scope.channel.values.chId){
            firebase.database().ref('/public/channels/' + scope.channel.recommend.channels[index] + '/about/recommendations/' + scope.channel.values.chId)
                               .set({name: scope.channel.values.identity.name})
                               .then(function(){
                scope.index.fadePopUp('out');
            });       
        } else {
            setTimeout(recommendContinue, 50);
        }
    }
    recommendContinue();
}

function removeRecommendation(index){
    var ch = scope.index.channels[index];
    firebase.database().ref('/public/channels/' + scope.channel.values.chId + '/about/recommendations/' + ch.id).remove();
    scope.index.channels.splice(index,1);
}
