function initDashboardContent(){
    scope.dashboard = {
        menuDown: true,
        loading: true,
        myChannels:[],
        subscribed:[],
        retrievingData: false,

        notifications: [],
        getNotifications: getNotifications,

        contentDashboardUsefulList: contentDashboardUsefulList,

        newsAmount: 'MORE',
        getNewsPosts: getNewsPosts
    }

    scope.dashboard.loading = true;
    local.newNotification = true;

    switch(scope.index.page.urlVars.page){
        case 'MYCHANNELS':
            contentDashboardMyChannels();
            break;
        case 'NEWS':
            contentDashboardNews();
            break;
        case 'NOTIFICATIONS':
            scope.index.newNotifications = false;
            getNotifications();
            break;
        case 'USEFUL-LIST':
            contentDashboardUsefulList();
            break;
        case 'SETTINGS':
            contentSettings();
            break;
    }
}

function contentDashboardMyChannels(times){
    if(scope.index.user.settings !== undefined){
        scope.dashboard.myChannels = [];
        if(scope.index.user.channels !== undefined){
            var array = Object.keys(scope.index.user.channels);
            array.forEach(function(item){
                firebase.database().ref("public/channels/" + item + '/values').once("value").then(function(snapshot) {
                    if(snapshot.val() !== null){
                        scope.dashboard.myChannels.push({
                            id: item,
                            name: scope.index.user.channels[item].name,
                            profilePic: scope.index.user.channels[item].profilePic,
                            subscribers: snapshot.val().subscribers,
                        });
                    }
                    if(array.indexOf(item) === array.length -1){
                        scope.dashboard.loading = false;
                        scope.$applyAsync();
                    }
                });
            });
        } else {
            scope.dashboard.loading = false;
            scope.$applyAsync();
        }
    } else {
        setTimeout(function(){contentDashboardMyChannels()} ,50);
    }
}

function contentDashboardNews(){
    var uid = firebase.auth().currentUser.uid;
    scope.index.retrievingData = true;
    scope.index.channels = [];
    scope.index.posts = [];
    scope.index.postsEnd = false;
    scope.index.channelsEnd = false;
    scope.$applyAsync();
    firebase.database().ref("private/" + uid + '/subscribed').once("value").then(function(snapshot) {
        if(snapshot.val()!== null){
            var obj = snapshot.val();
            var array = Object.keys(obj);
            var resultObj = {}
            var pushedOnce = false;
            var count = 0;
            array.forEach(function(item){
                if(obj[item].state === 'on'){
                    firebase.database().ref('/public/channels/' + item).once('value').then(function(snapshot){
                        if(snapshot.val() !== null){
                            pushedOnce = true;
                            resultObj[item] = snapshot.val();
                            countEvent();
                        } else {
                            firebase.database().ref("private/" + uid + '/subscribed/' + item).remove();
                            countEvent();
                        }
                    });
                } else {
                    countEvent();
                }
            });

            function countEvent(){
                count++;
                if(count === array.length){
                    if(!pushedOnce){
                        resultObj = null;
                    }
                    console.log(resultObj);
                    displayChannels(resultObj, true);
                    getNewsPosts(true);
                }
            }
        } else {
            displayChannels(null);
        }
    });
}

function getNewsPosts(firstTime){
    if(!scope.index.retrievingData){
        scope.index.retrievingData = true;
        var count, i;
        if(firstTime){
            count = 0;
            for(i = 0; i < scope.index.channels.length; i++){
                function channelsLastPost(index){
                    firebase.database().ref('/public/posts')
                                       .orderByChild('values/channel_new')
                                       .startAt(scope.index.channels[index].id + '--/-//-').endAt(scope.index.channels[index].id + '--/-//-' + "\uf8ff")
                                       .limitToLast(1).once('value').then(function(snapshot){
                        if(snapshot.val() !== null){
                            var array = Object.keys(snapshot.val()); 
                            local.postEachChannel[index] = snapshot.val()[array[0]];
                            local.postEachChannel[index].id = array[0];
                        } else {
                            local.postEachChannel[index] = null;
                        }
                        count++;
                        if(count === scope.index.channels.length){
                            arrayLastPost(local.postsRetrieved, true);
                        }
                    });
                }
                channelsLastPost(i);
            }
        } else {
            arrayLastPost(local.postsRetrieved - 1, false);
        }
    }
}

function arrayLastPost(counter, firstTime){
    if(counter === -1){
        local.resultArray.reverse();
        displayPosts(local.resultArray, firstTime);
        local.resultArray = [];
    } else {
        var biggestPost = getBiggestPost();
        if(biggestPost === null){
            local.resultArray.reverse();
            displayPosts(local.resultArray, firstTime);
            local.resultArray = [];
        } else {
            local.resultArray.push(biggestPost);
            firebase.database().ref('/public/posts')
                                .orderByChild('values/channel_new')
                                .startAt(biggestPost.channel + '--/-//-').endAt(biggestPost.values.channel_new)
                                .limitToLast(2).once('value').then(function(snapshot){
                var array = Object.keys(snapshot.val());
                if(array.length > 1){
                    local.postEachChannel[biggestPost.indexChannel] = snapshot.val()[array[0]];
                    local.postEachChannel[biggestPost.indexChannel].id = array[0];
                } else {
                    local.postEachChannel[biggestPost.indexChannel] = null;
                }
                arrayLastPost(counter - 1, firstTime);
            });
        }        
    }
}

function getBiggestPost(){
    var biggestPost = local.postEachChannel[0];
    if(biggestPost !== null){
        biggestPost.indexChannel = 0;   
    }
    for(var i = 1; i < local.postEachChannel.length; i++){
        if(biggestPost === null && local.postEachChannel[i] !== null || local.postEachChannel[i] !== null && biggestPost.id < local.postEachChannel[i].id){
            biggestPost = local.postEachChannel[i];
            biggestPost.indexChannel = i;
        }
    }
    return biggestPost;
}

function getNotifications(nextValues){
    if(!scope.dashboard.retrievingData){
        scope.dashboard.retrievingData = true;
        var uid = firebase.auth().currentUser.uid;
        var ref = null;
        const limitTo = 30;
        if(!nextValues){
            ref = firebase.database().ref("private/" + uid + '/notifications').limitToLast(limitTo);
        } else {
            index = scope.dashboard.notifications.length -1;
            ref = firebase.database().ref("private/" + uid + '/notifications').orderByKey().endAt(scope.dashboard.notifications[index].id).limitToLast(limitTo);
        }

        var lastSeenId = undefined;
        var once = true;
        firebase.database().ref("private/" + uid + '/notifications/lastSeen/id').once('value').then(function(snapshot){
            lastSeenId = snapshot.val() ? snapshot.val() : '';
        });

        ref.once("value").then(function(snapshot) {
            if(snapshot.val() !== null){
                var array = Object.keys(snapshot.val());

                if(limitTo > array.length){
                    scope.dashboard.notificationsEnd = true;
                }

                if(nextValues){
                    array.pop();
                } else {
                    scope.dashboard.notifications = [];
                    local.newNotification = true;
                }

                array.reverse();

                function continueNotifications(){
                    if(lastSeenId !== undefined){
                        array.forEach(function(item){
                            if(item !== 'lastSeen'){
                                if(lastSeenId >= item){
                                    local.newNotification = false;
                                } else {
                                    if(once){
                                        once = false;
                                        firebase.database().ref("private/" + uid + '/notifications/lastSeen').set({id: item});
                                    }
                                }

                                scope.dashboard.notifications.push({
                                    id: item,
                                    newNotification: local.newNotification,
                                    data: snapshot.val()[item],
                                    index: scope.dashboard.notifications.length
                                });
            
                                var dt = new Date(snapshot.val()[item].time);
                                scope.dashboard.notifications[scope.dashboard.notifications.length - 1].data.date = 
                                dt.getDate() + '/' + dt.getMonth() + '/' + dt.getFullYear() + ' - ' + twoDigits(dt.getHours()) + ':' + twoDigits(dt.getMinutes());
            
                                function twoDigits(x){
                                    return x < 10 ? '0' + x : x;
                                }
            
                                getNotificationRefference(scope.dashboard.notifications.length -1);
                            }
                        });
                    } else {
                        setTimeout(continueNotifications, 10);
                    }
                }
                continueNotifications();
            }

            scope.dashboard.retrievingData = false;
            scope.dashboard.loading = false;
            scope.index.newNotifications = false;
            scope.$applyAsync();
        });
    }
}

function getNotificationRefference(index){
    var uid = firebase.auth().currentUser.uid;
    var n = scope.dashboard.notifications[index];

    if(n.data.type === 'like'){
        firebase.database().ref("public/posts/" + n.data.for + '/content/title').once("value").then(function(snapshot) {
            if(snapshot.val() !== null){
                n.data.title = snapshot.val();
            } else {
                n.delete = true;
                firebase.database().ref("private/" + uid + '/notifications/' + n.id).remove();
            }
            scope.$applyAsync();
        });
    }

    if(n.data.type === 'subscribed'){
        firebase.database().ref("public/channels/" + n.data.for + '/identity/name').once("value").then(function(snapshot) {
            if(snapshot.val() !== null){
                n.data.title = snapshot.val();
            } else {
                n.delete = true;
                firebase.database().ref("private/" + uid + '/notifications/' + n.id).remove();
            }
            scope.$applyAsync();
        });
    }

    if(n.data.type === 'comment'){
        firebase.database().ref("public/channels/" + n.data.from + '/identity/name').once("value").then(function(snapshot) {
            if(snapshot.val() !== null){
                n.data.title = snapshot.val();
            } else {
                n.delete = true;
                firebase.database().ref("private/" + uid + '/notifications/' + n.id).remove();
            }
            scope.$applyAsync();
        });

        firebase.database().ref("public/posts/" + n.data.for + '/content/title').once("value").then(function(snapshot) {
            if(snapshot.val() !== null){
                n.data.title1 = snapshot.val();
            } else {
                n.delete = true;
                firebase.database().ref("private/" + uid + '/notifications/' + n.id).remove();
            }
            scope.$applyAsync();
        });

        firebase.database().ref("public/comments/" + n.data.commentId + '/text').once("value").then(function(snapshot) {
            if(snapshot.val() === null){
                n.delete = true;
                firebase.database().ref("private/" + uid + '/notifications/' + n.id).remove();
            }
            scope.$applyAsync();
        });
    }

    if(n.data.type === 'replayed-comment'){
        firebase.database().ref("public/channels/" + n.data.from + '/identity/name').once("value").then(function(snapshot) {
            if(snapshot.val() !== null){
                n.data.title = snapshot.val();
            } else {
                n.delete = true;
                firebase.database().ref("private/" + uid + '/notifications/' + n.id).remove();
            }
            scope.$applyAsync();
        });

        firebase.database().ref("public/comments/" + n.data.parentCommentId + '/text').once("value").then(function(snapshot) {
            if(snapshot.val() !== null){
                n.data.text = snapshot.val();
            } else {
                n.delete = true;
                firebase.database().ref("private/" + uid + '/notifications/' + n.id).remove();
            }
            scope.$applyAsync();
        });
    }

    if(n.data.type === 'answered-replay'){
        firebase.database().ref("public/channels/" + n.data.from + '/identity/name').once("value").then(function(snapshot) {
            if(snapshot.val() !== null){
                n.data.title = snapshot.val();
            } else {
                n.delete = true;
                firebase.database().ref("private/" + uid + '/notifications/' + n.id).remove();
            }
            scope.$applyAsync();
        });

        firebase.database().ref("public/comments/" + n.data.commentId + '/text').once("value").then(function(snapshot) {
            if(snapshot.val() !== null){
                n.data.text = snapshot.val();
            } else {
                n.delete = true;
                firebase.database().ref("private/" + uid + '/notifications/' + n.id).remove();
            }
            scope.$applyAsync();
        });
    }

    if(n.data.type === 'comment-like'){
        firebase.database().ref("public/comments/" + n.data.commentId + '/text').once("value").then(function(snapshot) {
            if(snapshot.val() !== null){
                n.data.text = snapshot.val();
            } else {
                n.delete = true;
                firebase.database().ref("private/" + uid + '/notifications/' + n.id).remove();
            }
            scope.$applyAsync();
        });
    }

    if(n.data.type === 'replay-like'){
        firebase.database().ref("public/comments/" + n.data.commentId + '/text').once("value").then(function(snapshot) {
            if(snapshot.val() !== null){
                n.data.text = snapshot.val();
            } else {
                n.delete = true;
                firebase.database().ref("private/" + uid + '/notifications/' + n.id).remove();
            }
            scope.$applyAsync();
        });
    }
}

function checkNotifications(){
    if(firebase.auth().currentUser){
        var uid = firebase.auth().currentUser.uid;
        firebase.database().ref("private/" + uid + '/notifications').orderByKey().limitToLast(2).once('value').then(function(snapshot){
            if(snapshot.val() !== null){
                var array = Object.keys(snapshot.val());
                if(array[1] !== 'lastSeen' && snapshot.val()[array[0]] !== undefined){
                    scope.index.newNotifications = true;
                    scope.$applyAsync()
                } else {
                    if(snapshot.val()[array[1]] !== undefined && array[0] > snapshot.val()[array[1]].id){
                        scope.index.newNotifications = true;
                        scope.$applyAsync()
                    }
                }
            }
        });
    }
}

function contentDashboardUsefulList(nextValues){    
    if(!scope.index.retrievingData || !nextValues){
        scope.index.retrievingData = true;
        var ref;
        var uid = firebase.auth().currentUser.uid;
        if(!nextValues){
            scope.index.posts = [];
            scope.$applyAsync();
            ref = firebase.database().ref('private/' + uid + '/usefulList').limitToLast(local.postsRetrieved);
        } else {
            ref = firebase.database().ref('private/' + uid + '/usefulList').orderByKey().endAt(local.lastUsefulListId).limitToLast(local.postsRetrieved);
        }

        ref.once('value').then(function(snapshot){
            var array = snapshot.val() !== null ? Object.keys(snapshot.val()) : [];
            if(nextValues){
                array.pop();
            }
            local.lastUsefulListId = array[0] !== undefined ? array[0] : '';
            var arrayPostIds  = [];
            array.forEach(function(item){
                arrayPostIds.push(snapshot.val()[item].id);
            });

            local.resultArray = [];
            var count = 0;

            if(arrayPostIds.length > 0){
                for( var i = 0; i < arrayPostIds.length ; i++){
                    function addPostToJson(index){
                        firebase.database().ref('public/posts/' + arrayPostIds[index]).once("value").then(function(snapshot){
                            if(snapshot.val() !== null){
                                local.resultArray.push(snapshot.val());
                                local.resultArray[local.resultArray.length - 1].id = arrayPostIds[index];
                            } else {
                                firebase.database().ref('private/' + uid + '/usefulList/' + array[index]).remove();
                            }
                            count++;
                            if(count === arrayPostIds.length){
                                displayPosts(local.resultArray, !nextValues);
                            }
                        });
                    }
                    addPostToJson(i);
                }
            } else {
                scope.dashboard.loading = false;
                displayPosts([]);
            }
        });
    }
}

function contentSettings(){
    scope.dashboard.settings = {
        loading: true
    }

    local.userAuth = firebase.auth().currentUser;

    function getAuthProvider(){
        if(local.userAuth.providerData[0].providerId === 'password'){
            return 'password';
        }

        if(local.userAuth.providerData[0].providerId === 'twitter.com'){
            return 'TWITTER';
        }

        if(local.userAuth.providerData[0].providerId === 'facebook.com'){
            return 'FACEBOOK';
        }

        if(local.userAuth.providerData[0].providerId === 'google.com'){
            return 'GOOGLE+';
        }
    }

    function getUser(){
        if(scope.index.user.settings !== undefined && local.userAuth !== undefined){
            scope.dashboard.settings = {
                contactEmail: scope.index.user.settings.email ? scope.index.user.settings.email + '' : '',
                nsfw: scope.index.user.settings.nsfw + '',

                authProvider: getAuthProvider(),
                signInEmail: local.userAuth.providerData[0].email + '',
                sameEmail: true,
                sameEmailFunc: function(){
                    if(scope.dashboard.settings.sameEmail){
                        scope.dashboard.settings.contactEmail = scope.dashboard.settings.signInEmail + '';
                    }
                },
                error:{
                    exists: false,
                    format: false,
                    empty: false,
                    weak: false,
                    matching: false,
                    password: false,
                    wrongPassword: false
                },
                
                loading: false,
                saveInProgress: false,
                saveSettings: saveSettings,

                currentPassword: '',
                newPassword: '',
                repeatPassword: '',

                deleteAccount: deleteAccount
            }
            scope.$applyAsync();
        } else {
            setTimeout(getUser, 50);
        }
    }
    getUser();
}

function saveSettings(){
    if(!scope.dashboard.settings.saveInProgress){
        scope.dashboard.settings.saveInProgress = true;

        if(scope.dashboard.settings.authProvider === 'password'){
            if(scope.dashboard.settings.signInEmail !== local.userAuth.providerData[0].email || scope.dashboard.settings.newPassword !== ''){
                var loginError = false;
                if(scope.dashboard.settings.currentPassword !== ''){
                    firebase.auth().signInWithEmailAndPassword(local.userAuth.providerData[0].email, scope.dashboard.settings.currentPassword)
                    .catch(function(error){
                        loginError = true;
                    })
                    .then(function(user) {
                        if(!loginError){
                            if(scope.dashboard.settings.signInEmail !== local.userAuth.providerData[0].email){
                                if(scope.dashboard.settings.signInEmail !== ''){
                                    user.updateEmail(scope.dashboard.settings.signInEmail).catch(function(e){
                                        loginError = e.code;
                                    }).then(function(){
                                        if(loginError === false){
                                            scope.dashboard.settings.saveInProgress = false;
                                            if(scope.dashboard.settings.newPassword !== ''){
                                                if(scope.dashboard.settings.newPassword.length >= 6){
                                                    if(scope.dashboard.settings.newPassword === scope.dashboard.settings.repeatPassword){
                                                        user.updatePassword(scope.dashboard.settings.newPassword).catch(function(e){
                                                            console.log(e);
                                                        }).then(function(){
                                                            firebase.database().ref('private/' + local.userAuth.uid + '/user/settings').set({
                                                                email: scope.dashboard.settings.contactEmail,
                                                                nsfw: scope.dashboard.settings.nsfw
                                                            }).then(function(){
                                                                scope.index.user.settings = {
                                                                    email: scope.dashboard.settings.contactEmail,
                                                                    nsfw: scope.dashboard.settings.nsfw
                                                                }
                                                                scope.dashboard.settings.currentPassword = '';
                                                                scope.dashboard.settings.newPassword = '';
                                                                scope.dashboard.settings.repeatPassword = '';
                                                                scope.dashboard.settings.saveInProgress = false;
                                                                scope.$applyAsync();
                                                            });
                                                        });
                                                    } else {
                                                        scope.dashboard.settings.error.matching = true;
                                                        scope.dashboard.settings.saveInProgress = false;
                                                        scope.$applyAsync();
                                                    }
                                                } else {
                                                    scope.dashboard.settings.error.weak = true;
                                                    scope.dashboard.settings.saveInProgress = false;
                                                    scope.$applyAsync();
                                                }
                                            } else {
                                                firebase.database().ref('private/' + local.userAuth.uid + '/user/settings').set({
                                                    email: scope.dashboard.settings.contactEmail,
                                                    nsfw: scope.dashboard.settings.nsfw
                                                }).then(function(){
                                                    scope.index.user.settings = {
                                                        email: scope.dashboard.settings.contactEmail,
                                                        nsfw: scope.dashboard.settings.nsfw
                                                    }
                                                    scope.dashboard.settings.saveInProgress = false;
                                                    scope.$applyAsync();
                                                });
                                            }
                                        } else {
                                            if(loginError === "auth/email-already-in-use"){
                                                scope.dashboard.settings.error.exists = true;
                                            } else {
                                                scope.dashboard.settings.error.format = true;
                                            }
                                            scope.dashboard.settings.saveInProgress = false;
                                            scope.$applyAsync();
                                        }
                                    });
                                } else {
                                    scope.dashboard.settings.error.empty = true;
                                    scope.dashboard.settings.saveInProgress = false;
                                    scope.$applyAsync();
                                }

                            } else {
                                if(scope.dashboard.settings.newPassword !== ''){
                                    if(scope.dashboard.settings.newPassword.length >= 6){
                                        if(scope.dashboard.settings.newPassword === scope.dashboard.settings.repeatPassword){
                                            user.updatePassword(scope.dashboard.settings.newPassword).catch(function(e){
                                                console.log(e);
                                            }).then(function(){
                                                firebase.database().ref('private/' + local.userAuth.uid + '/user/settings').set({
                                                    email: scope.dashboard.settings.contactEmail,
                                                    nsfw: scope.dashboard.settings.nsfw
                                                }).then(function(){
                                                    scope.index.user.settings = {
                                                        email: scope.dashboard.settings.contactEmail,
                                                        nsfw: scope.dashboard.settings.nsfw
                                                    }
                                                    scope.dashboard.settings.currentPassword = '';
                                                    scope.dashboard.settings.newPassword = '';
                                                    scope.dashboard.settings.repeatPassword = '';
                                                    scope.dashboard.settings.saveInProgress = false;
                                                    scope.$applyAsync();
                                                });
                                            });
                                        } else {
                                            scope.dashboard.settings.error.matching = true;
                                            scope.dashboard.settings.saveInProgress = false;
                                            scope.$applyAsync();
                                        }
                                    } else {
                                        scope.dashboard.settings.error.weak = true;
                                        scope.dashboard.settings.saveInProgress = false;
                                        scope.$applyAsync();
                                    }
                                }
                            }
                        } else {
                            scope.dashboard.settings.error.wrongPassword = true;
                            scope.dashboard.settings.saveInProgress = false;
                            scope.$applyAsync();
                        }
                    });                    
                } else {
                    scope.dashboard.settings.error.password = true;
                    scope.dashboard.settings.saveInProgress = false;
                    scope.$applyAsync();
                }
            } else {
                firebase.database().ref('private/' + local.userAuth.uid + '/user/settings').set({
                    email: scope.dashboard.settings.contactEmail,
                    nsfw: scope.dashboard.settings.nsfw
                }).then(function(){
                    scope.index.user.settings = {
                        email: scope.dashboard.settings.contactEmail,
                        nsfw: scope.dashboard.settings.nsfw
                    }
                    scope.dashboard.settings.saveInProgress = false;
                    scope.$applyAsync();
                });
            }
        } else {
            firebase.database().ref('private/' + local.userAuth.uid + '/user/settings').set({
                email: scope.dashboard.settings.contactEmail,
                nsfw: scope.dashboard.settings.nsfw
            }).then(function(){
                scope.index.user.settings = {
                    email: scope.dashboard.settings.contactEmail,
                    nsfw: scope.dashboard.settings.nsfw
                }
                scope.dashboard.settings.saveInProgress = false;
                scope.$applyAsync();
            });
        }
    }
}

function deleteAccount(){
    scope.index.delete = {
        what: 'account',
        loading: false,
        
        currentPassword: '',
        password: false,
        wrongPassword: false,
        providerError: false,
        email: local.userAuth.providerData[0].email + '',
        provider: local.userAuth.providerData[0].providerId,
        user: local.userAuth,

        func: deleteContent
    }

    function deleteContent(){
        if(!scope.index.delete.loading){
            scope.index.delete.loading = true;

            var loginError = false;
            if(scope.index.delete.provider === 'password'){
                if(scope.index.delete.currentPassword !== ''){
                    firebase.auth().signInWithEmailAndPassword(scope.index.delete.email, scope.index.delete.currentPassword)
                    .catch(function(error){
                        loginError = true;
                    })
                    .then(function(user) {
                        if(!loginError){
                            firebase.database().ref('private/' + user.uid).remove().then(function(){
                                //changeURL('/');
                                user.delete().then(function(){
                                    changeURL('/');
                                });
                            });                       
                        } else {
                            scope.index.delete.wrongPassword = true;
                            scope.index.delete.loading = false;
                            scope.$applyAsync();
                        }
                    })
                } else {
                    scope.index.delete.password = true;
                    scope.index.delete.loading = false;
                    scope.$applyAsync();
                }
            } else {
                var provider;
                switch(scope.index.delete.provider){
                    case 'facebook.com':
                        provider = new firebase.auth.FacebookAuthProvider();
                        break;
                    case 'twitter.com':
                        provider = new firebase.auth.TwitterAuthProvider();
                        break;
                    case 'google.com':
                        provider = new firebase.auth.GoogleAuthProvider();
                        break;
                }

                scope.index.delete.user.reauthenticateWithPopup(provider).then(function(result) {
                    var user = result.user;
                    firebase.database().ref('private/' + user.uid).remove().then(function(){
                        user.delete().then(function(){
                            changeURL('/');
                        });
                    }); 
                }, function(error) {
                    scope.index.delete.providerError = true;
                    scope.index.delete.loading = false;
                    scope.$applyAsync();
                });
            }
        }
    }

    scope.index.fadePopUp('in', 'delete');
}
