function initCategoriesContent(){
    if(scope.categories === undefined){
        scope.categories = {
            list: [],
            retrievingData: true
        }
        getCategoriesList();
    }
}

function getCategoriesList(){
    firebase.database().ref("categories").once("value").then(function(snapshot) {
        scope.categories.list = Object.keys(snapshot.val());
        scope.categories.retrievingData = false;
        scope.$applyAsync();
    });
}
