var app = angular.module('useful_indeed', []), scope, local;
app.filter('trusted', ['$sce', function ($sce) {
    return $sce.trustAsResourceUrl;
}]);

app.controller('useful_indeed_controller', ['$scope', '$http', '$compile', function($scope, $http, $compile) {
    local = {
        http: $http,
        compile: $compile,

        groundZero: true,
        logInPromise: '',
        finishedLoading: {
            htmlPages: false,
            pageDisplay: false
        },
        prevScroll: 0,
        profilePic: 'https://firebasestorage.googleapis.com/v0/b/usefulindeed-c3831.appspot.com/o/defaults%2Fdefault-profilePic.svg?alt=media&token=6aa74757-3f19-4905-833f-10137bc61227',
        coverPic: 'https://firebasestorage.googleapis.com/v0/b/usefulindeed-c3831.appspot.com/o/defaults%2Fdefault-coverPic.svg?alt=media&token=2f1f353c-c9a7-4a3e-85f2-b00bcc2fc912',
        
        channelMenuClick: false,

        newNotification: true,
        notificationCheck: null,

        postsRetrieved: 30,
        iteration: 0,

        postEachChannel: [],
        resultArray: [],
        lastUsefulListId: '',
        userAuth:undefined,
        replaisRetrieved: '',

        searchLimit: 12,
        prevId: '',
        lastSearchText: '',
        resultsFound: false
    };
    initScope($scope);

    window.onresize = function(event) {
        scope.$applyAsync();
    };
}]);

function initScope($scope){
    scope = $scope;
    scope.index = getIndexScope();
    scope.dashboard = {};
    scope.channel = {
        values:{},
        likeClick : likeClick,
        usefulListClick : usefulListClick
    };

    loadHTMLPages();
    authState();
}

function getIndexScope(){
    return {
        authState: false,
        dropdown: '',

        popUp: false,
        popUpContent: '',
        error:{
            passwordMissmatch: false,
            emailExists: false,
            weakPassword: false,
            badEmailFormat: false,
            wrongCredentials: false,

            nameFirstChannel: false
        },
        buttonPressed:{
            JoinSignIn: false,
            resetPassword: false,
            nameFirstChannel: false,
            report: false
        },
        page: {
            pageName: '',
            urlVars: {}
        },
        user: {},

        bodyClick: bodyClick,
        dropDownEvent: dropDownEvent,
        fadePopUp: fadePopUp,
        providerAuth: providerAuth,
        emailAuth: emailAuth,
        iForgotMyPassword: iForgotMyPassword,
        resetPassword: resetPassword,
        nameFirstChannel: nameFirstChannel,
        signOut: signOut,
        changeURL: changeURL,
        isMobile: function(){ return window.innerWidth < 991 ? true : false; },
        isMine: isMine,

        editSelections:{
            channel: '',
            collection: '',
            category: ''
        },

        getYotubeVideoUrl: getYotubeVideoUrl,
        getAHrefURL: getAHrefURL,
        aHrefClick: aHrefClick,

        newNotifications: false,
        pinterestShareURL: pinterestShareURL,
        report: report,
        reportVars:{
            type: '',
            id: '',
            reason: ''
        },
        reportReasons:[
            'SPAM',
            'PORNOGRAPHY',
            'HATRED AND BULLYING',
            'SELF-HARM',
            'VIOLENT, GORY AND HARMFUL CONTENT',
            'ILLEGAL ACTIVITIES e.g. DRUG USE',
            'DECEPTIVE CONTENT',
            'COPYRIGHT AND TRADEMARK INFRINGEMENT',
            "I JUST DON'T LIKE IT"
        ],
        reportContent: reportContent,

        posts: [],
        retrievingData: false,
        postsEnd: false,
        likeClick: likeClick,
        usefulListClick: usefulListClick,

        endAt: '',
        channels: [],
        channelsEnd: false,
        subscribeClickIndex: subscribeClickIndex,
        collections: [],
        collectionsEnd : false,

        feedbackText: '',
        feedbackSending: false,
        sendFeedback: sendFeedback,
    }
}

function loadHTMLPages(){
    // add channel, dashboard...
    var pages = ['explore', '404','dashboard','channel', 'edit','categories', 'search', 'about'];
    var countLoadHTML = pages.length;

    pages.forEach(function(item){
        local.http.get("../../html/" + item + '.html').then(function(response) {
            angular.element(document.querySelector(".page-container")).prepend(local.compile(response.data)(scope));
            if(--countLoadHTML === 0){
                if(local.finishedLoading.pageDisplay){
                    fadeOutLoading();
                } else {
                    local.finishedLoading.htmlPages = true;
                }
            }
        });
    });
}

function authState(){
    firebase.auth().onAuthStateChanged(function(user) {
        if(local.groundZero){
            if (user) {
                checkNotifications();
                local.notificationCheck = setInterval(checkNotifications, 30000);

                scope.index.authState = true;
                getUserData(user);
            } else {
                scope.index.authState = false;
                scope.index.user = {};
                clearInterval(local.notificationCheck);
            }
            scope.$applyAsync();
            changeURL();
        } else {
            location.reload();
        }
    });
}

function signOut(){
    if(!scope.index.page.pagePublic){
        changeURL('/');
    }
    firebase.auth().signOut();
}

function changeURL(url){
    local.prevScroll = 0;
    local.channelMenuClick = false;

    var URL = window.location.href.substr(window.location.origin.length);
    var page = url ? parseURL(url) : parseURL(URL);

    if(!page.pagePublic && scope.index.authState || page.pagePublic){
        if(url || local.groundZero || local.logInPromise === 'popUp'){
            local.logInPromise = 'end';
            if(local.groundZero){
                if(page.pageName !== '404'){

                    var obj = {
                        scroll: window.scrollY,
                        local: JSONfn.stringify(local),
                        index: JSONfn.stringify(scope.index),
                        search: JSONfn.stringify(scope.search),
                        explore: JSONfn.stringify(scope.explore),
                        edit: JSONfn.stringify(scope.edit),
                        dashboard: JSONfn.stringify(scope.dashboard),
                        channel: JSONfn.stringify(scope.channel),
                        categories: JSONfn.stringify(scope.categories),
                    }
                    window.history.replaceState(obj, null, "../.." + (url ? url : URL)); // ../ there 
                }
            } else {

                var obj = {
                    scroll: window.scrollY,
                    local: JSONfn.stringify(local),
                    index: JSONfn.stringify(scope.index),
                    search: JSONfn.stringify(scope.search),
                    explore: JSONfn.stringify(scope.explore),
                    edit: JSONfn.stringify(scope.edit),
                    dashboard: JSONfn.stringify(scope.dashboard),
                    channel: JSONfn.stringify(scope.channel),
                    categories: JSONfn.stringify(scope.categories),
                }
                window.history.replaceState(obj, null, "../.." + URL); // ../ there

                if(page.pageName !== '404' && url !== undefined){
                    window.history.pushState(null, null, "../.." + url ); // ../ there
                }
            }
            scope.index.page = page;
            scope.$applyAsync();

            if(local.groundZero){
                if(local.finishedLoading.htmlPages){
                    fadeOutLoading();
                } else {
                    local.finishedLoading.pageDisplay = true;
                }
            }

            if(!local.channelMenuClick){ //don't scroll page up if menu click from channel
                window.scrollTo(0, 0);
            }

            initPageContent();
        }
    } else {
        if(local.groundZero){
            local.logInPromise = 'changeURL';
            scope.index.fadePopUp('in','Sign In');
            fadeOutLoading();
        } else {
            changeURL('/');
        }
    }
}

function parseURL(url){
    var varsURL = [], page={ pageName: '', pagePublic: true, urlVars: {}}, pageFound = false;
    url.split("/").forEach(function(item){
        if(item !== ""){
            varsURL.push(item);
        }
    });

    var array = ['HOT','TRENDY','NEW','HOWTOS','PRODUCTS','EXPERIENCES','LEARNABLES'];
    if(varsURL[0] === undefined || array.indexOf(varsURL[0].toLocaleUpperCase()) !== -1){
        pageFound = true;
        page.pageName = 'explore';
        page.urlVars = {
            title: varsURL[0] ? varsURL[0].toLocaleUpperCase() === 'HOWTOS' ? 'HOW TOs' : varsURL[0].toLocaleUpperCase()  : 'NEW',
            filter: 'new'
        };
    } else {
        if(varsURL[0].toLocaleUpperCase() === 'DASHBOARD'){
            array = ['NEWS','USEFUL-LIST','NOTIFICATIONS','MYCHANNELS','SETTINGS'];
            if(varsURL[1] !== undefined && array.indexOf(varsURL[1].toLocaleUpperCase()) !== -1){
                pageFound = true;
                page.pageName = 'dashboard';
                page.pagePublic = false;
                page.urlVars = {
                    page: varsURL[1].toLocaleUpperCase()
                };
            }
        }

        if(varsURL[0].toLocaleUpperCase() === 'CHANNEL' && varsURL[1] !== undefined){
            page.pageName = 'channel';
            page.pagePublic = true;
            
            array = ['ABOUT','CHANNELS','COLLECTIONS','POSTS'];
            if(varsURL[2] === undefined || array.indexOf(varsURL[2].toLocaleUpperCase()) !== -1){
                if(varsURL[1].toLowerCase() === scope.index.page.urlVars.id && scope.index.page.pageName === 'channel'){
                    local.channelMenuClick = true;
                }
                pageFound = true;
                page.urlVars = {
                    id: varsURL[1],
                    page: varsURL[2] === undefined ? 'POSTS' : varsURL[2].toLocaleUpperCase()
                };
            }
        }
        if((varsURL[0].toLocaleUpperCase() === 'COLLECTION' || varsURL[0].toLocaleUpperCase() === 'POST') && varsURL[1] !== undefined){
            page.pageName = 'channel';
            page.pagePublic = true;
            page.urlVars = {
                id: '',
                page: varsURL[0].toLocaleUpperCase(),
                partId: varsURL[1],
                comment: varsURL[2]
            };
            pageFound = true;
        }

        if(varsURL[0].toLocaleUpperCase() === 'EDIT'){
            array = ['CHANNEL','CHANNELS','COLLECTION','POST'];
            if(varsURL[1] !== undefined && array.indexOf(varsURL[1].toLocaleUpperCase()) !== -1){
                pageFound = true;
                page.pageName = 'edit';
                page.pagePublic = false;
                page.urlVars = {
                    page: varsURL[1].toLocaleUpperCase(),
                    id: varsURL[2]
                };
            }
        }

        if(varsURL[0].toLocaleUpperCase() === 'CATEGORIES'){
            pageFound = true;

            if(varsURL[1] === undefined){
                page.pageName = 'categories';

            } else {
                page.pageName = 'explore';
                page.urlVars = {
                    isCategories: true,
                    title: varsURL[1].toLocaleUpperCase(),
                    filter: 'new'
                };
            }
        }

        if(varsURL[0].toLocaleUpperCase() === 'SEARCH'){
            pageFound = true;
            page.pageName = 'search';
        }

        if(['ABOUT','TERMS','PRIVACY','RULES'].indexOf(varsURL[0].toLocaleUpperCase()) !== -1){
            pageFound = true;
            page.pageName = 'about';
            page.urlVars = {page: varsURL[0].toLocaleUpperCase()};
        }
    }

    if(!pageFound){
        page.pageName = '404';
    }
    return page;
}

function initPageContent(){
    //if from history

    // if new
    document.body.scroll = 0;
    switch(scope.index.page.pageName){
        case 'explore':
            initExploreContent();
            break;

        case 'dashboard':
            initDashboardContent();
            break;

        case 'channel':
            initChannelContent();
            break;

        case 'edit':
            initEditContent();
            break;
        case 'categories':
            initCategoriesContent();
            break;

        case 'search':
            initSearchContent();
            break;
    }
}

// arrow navigation
window.addEventListener('load', function(){            
    this.addEventListener('popstate', function(event, state){
        state = event.state;
        if(state !== null){
            var notificationsState = scope.index.newNotifications;
            scope.index= state.index ? JSONfn.parse(state.index) : undefined;
            scope.index.newNotification = notificationsState;

            scope.search= state.search ? JSONfn.parse(state.search) : undefined;
            scope.explore= state.explore ? JSONfn.parse(state.explore) : undefined;
            scope.edit= state.edit ? JSONfn.parse(state.edit) : undefined;
            scope.dashboard= state.dashboard ? JSONfn.parse(state.dashboard) : undefined;
            scope.channel= state.channel ? JSONfn.parse(state.channel) : undefined;
            scope.categories= state.categories ? JSONfn.parse(state.categories) : undefined;
            local = state.local ? JSONfn.parse(state.local) : undefined;

            scope.index.dropdown = '';
            scope.$applyAsync();

            setTimeout(function(){
                window.scrollTo(0, state.scroll);
            }, 10);
        } else {
            changeURL(window.location.href.substr(window.location.origin.length));
        }
    }, false);
}, false);


function fadeOutLoading(){
    local.groundZero = false;

    document.querySelector(".loading-container").classList.add("loading-container-exit");
    document.querySelector(".loading-container .loading-gif").classList.add("display-none");

    setTimeout(function(){
        document.querySelector(".loading").classList.add("loading-exit");
        setTimeout(function(){
            document.querySelector(".loading").classList.add("display-none");
        },350);
    }, window.innerWidth <= 990 ? 550 : 500);
}

function getUserData(user){
    firebase.database().ref("private/" + user.uid + '/user').once("value").then(function(snapshot) {
        if(snapshot.val()){
            scope.index.user = snapshot.val();
        } else {
            firebase.database().ref("private/" + user.uid + '/user/settings').set({
                email: user.email,
                nsfw: 'off'
            });
            scope.index.user.settings = {
                email: user.email,
                nsfw: 'off'
            }
            fadePopUp('in', 'nameFirstChannel');
        }
        scope.$applyAsync();
    });
}

function isMine(chId){
    if(firebase.auth().currentUser !== null && scope.index.user.channels !== undefined){
        if(scope.index.user.channels[chId] !== undefined){
            return true;
        }
    }
    return false;
}

/* events */
function bodyClick(){
    if(scope.index.dropdown !== ''){
        scope.index.dropdown = '';
        scope.$applyAsync();
    }
}

function dropDownEvent($event, dropDown){
    $event.stopPropagation();
    if(dropDown !== scope.index.dropdown){
        scope.index.dropdown = dropDown;
    } else {
        scope.index.dropdown = '';
    }
    scope.$applyAsync();
}

function fadePopUp(type, content){
    if(type === 'in'){
        document.querySelector(".popUp").classList.remove("display-none");
        initPopUpVars();
        setTimeout(function(){
            scope.index.popUp = true;
            scope.index.popUpContent = content;
            scope.$applyAsync();
        },0);
    }
    if(type === 'out'){
        if(local.logInPromise === 'changeURL'){
            local.logInPromise = 'popUp';
            if(content === 'x'){
                changeURL('/');
            }
        }
        scope.index.popUp = false;
        scope.$applyAsync();
        setTimeout(function(){
            document.querySelector(".popUp").classList.add("display-none");
            initPopUpVars();
        },250);
    }
}

function providerAuth(provider){
    switch(provider){
        case 'facebook':
            provider = new firebase.auth.FacebookAuthProvider();
            break;
        case 'twitter':
            provider = new firebase.auth.TwitterAuthProvider();
            break;
        case 'google':
            provider = new firebase.auth.GoogleAuthProvider();
            break;
    }
    firebase.auth().signInWithRedirect(provider);
}

function emailAuth(){
    console.log('click');
    if(!scope.index.buttonPressed.JoinSignIn){
        scope.index.buttonPressed.JoinSignIn = true;

        var email = document.querySelector(".logIn-email").value;
        var password = document.querySelector(".logIn-password").value;

        scope.index.error = {
            passwordMissmatch: false,
            emailExists: false,
            weakPassword: false,
            badEmailFormat: false,
            wrongCredentials: false
        };
        scope.$applyAsync();

        if(scope.index.popUpContent === 'JOIN' && email !== '' && password !== ''){
            var confirmPassword = document.querySelector(".logIn-confirmPassword").value;
            if(password === confirmPassword){
                var noError = true;
                firebase.auth().createUserWithEmailAndPassword(email, password).catch(function(error) {
                    if(error.code === 'auth/weak-password'){
                        scope.index.error.weakPassword = true;
                        noError = false;
                    }
                    if(error.code === 'auth/invalid-email'){
                        scope.index.error.badEmailFormat = true;
                        noError = false;
                    }
                    if(error.code === 'auth/email-already-in-use'){
                        scope.index.error.emailExists = true;
                        noError = false;
                    }
                    scope.$applyAsync();
                }).then(function(){
                    if(noError){
                        fadePopUp('out');
                        firebase.auth().currentUser.sendEmailVerification();
                    }
                    scope.index.buttonPressed.JoinSignIn = false;
                });
            } else {
                scope.index.error.passwordMissmatch = true;
                scope.index.buttonPressed.JoinSignIn = false;
            }
        } else {
            if(scope.index.popUpContent === 'Sign In' && email !== '' && password !== ''){
                var noError = true;
                firebase.auth().signInWithEmailAndPassword(email, password).catch(function(error) {
                    scope.index.error.wrongCredentials = true;
                    noError = false;
                    scope.$applyAsync();
                }).then(function(){
                    if(noError){
                        fadePopUp('out');
                    }
                    scope.index.buttonPressed.JoinSignIn = false;
                });
            } else {
                scope.index.buttonPressed.JoinSignIn = false;
            }
        }
    }
}

function iForgotMyPassword(){
    initPopUpVars();
    fadePopUp('in', 'resetPassword');
}

function resetPassword(){
    if(!scope.index.buttonPressed.resetPassword){
        scope.index.buttonPressed.resetPassword = true;
        var emailAddress = document.querySelector(".resetPassword-email").value;
        scope.index.error.badEmailFormat = false;
        scope.index.error.wrongCredentials = false;
        scope.$applyAsync();
        var noError = true;
        firebase.auth().sendPasswordResetEmail(emailAddress).catch(function(error) {
            if(error.code === 'auth/invalid-email'){
                scope.index.error.badEmailFormat = true;
                noError = false;
            }
            if(error.code === 'auth/user-not-found'){
                scope.index.error.wrongCredentials = true;
                noError = false;
            }
            scope.$applyAsync();
        }).then(function() {
            if(noError){
                fadePopUp('in', 'resetPasswordSent');
            }
            scope.index.buttonPressed.resetPassword = false;
        });
    }
}

function initPopUpVars(){
    //auth
    if(document.querySelector(".logIn-email")){document.querySelector(".logIn-email").value = '';}
    if(document.querySelector(".logIn-password")){document.querySelector(".logIn-password").value = '';}
    if(document.querySelector(".logIn-confirmPassword")){document.querySelector(".logIn-confirmPassword").value = '';}
    if(document.querySelector(".resetPassword-email")){document.querySelector(".resetPassword-email").value = '';}
    scope.index.error = {
        passwordMissmatch: false,
        emailExists: false,
        weakPassword: false,
        badEmailFormat: false,
        wrongCredentials: false,

        nameFirstChannel: false
    };

    //renameFirstChannel
    if(document.querySelector(".name-firstChannel")){document.querySelector(".name-firstChannel").value = '';}
}

function nameFirstChannel(){
    if(!scope.index.buttonPressed.nameFirstChannel){
        scope.index.error.nameFirstChannel = false;
        scope.index.buttonPressed.nameFirstChannel = true;
        var name = document.querySelector(".name-firstChannel").value;
        if(name !== ''){
            var id = name.toLowerCase().replace(/\s/g, "");
            var uid = firebase.auth().currentUser.uid;
            var noError = true;

            firebase.database().ref('public/channels/' + id).set({
                uid: uid,
                identity:{
                    id: id,
                    name: name,
                    profilePic: local.profilePic,
                    coverPic: local.coverPic
                },
                values:{
                    subscribers: 0,
                    likes: 0
                }
            }).catch(function(error){
                noError = false;
                scope.index.error.nameFirstChannel = true;
            }).then(function(){
                if(noError){
                    firebase.database().ref('private/' + uid + '/user/channels/' + id).set({
                        id: id,
                        name: name,
                        profilePic: local.profilePic,
                        coverPic: local.coverPic
                    });

                    firebase.database().ref('public/collections/').push({
                        uid: uid,
                        channel: id,
                        content:{
                            name: '(default)',
                            nameSearch: '(default)',
                            description: ''
                        },
                        values:{
                            nrPosts: 0,
                            thumbnail: local.coverPic
                        }
                    })
                       
                    scope.index.user.channels = {};
                    scope.index.user.channels[id] = {
                        id: id,
                        name: name,
                        profilePic: local.profilePic,
                        coverPic: local.coverPic
                    }
                    fadePopUp('out');
                    changeURL('/dashboard/mychannels');
                }
                scope.index.buttonPressed.nameFirstChannel = false;
                scope.$applyAsync();
            });
        } else {
            scope.index.buttonPressed.nameFirstChannel = false;
        }
    }
}

function bodyScroll(){
    if(scope.index.page.pageName === 'dashboard'){
        if(local.prevScroll < window.scrollY){
            local.prevScroll = window.scrollY;
            scope.dashboard.menuDown = false;
        } else {
            local.prevScroll = window.scrollY;
            scope.dashboard.menuDown = true;
        }
        scope.$applyAsync();
    }
}

function getYotubeVideoUrl(url, thumbnailOnly){
    var regExp = /^.*(youtu.be\/|v\/|u\/\w\/|embed\/|watch\?v=|\&v=)([^#\&\?]*).*/;
    var match = url.match(regExp);

    if (match && match[2].length == 11) {
        if(thumbnailOnly){
            return 'https://img.youtube.com/vi/'+ match[2] +'/mqdefault.jpg';
        } else {
            return 'https://www.youtube.com/embed/' + match[2];
        }
    } else {
        return 'error';
    }
}

function getAHrefURL(url){
    return window.location.origin + '/../..' + url;
}

function aHrefClick(url, e){
    e.preventDefault(); 
    changeURL(url);
    return false;
}

function pinterestShareURL(id, post){
    return `http://www.pinterest.com/pin/create/button/?url=` + encodeURI(`https://www.usefulindeed.com/share/` + id)+
        `&media=` + encodeURI(post.ref.imageURL) +
        `&description=` + encodeURI('USABILITY: ' + post.content.usability);
}

function report(type, id){
    var user = firebase.auth().currentUser;
    if(user){
        scope.index.reportVars = {
            type: type,
            id: id,
            reason: '',
            email: ''
        }

        fadePopUp('in', 'report');
    } else {
        fadePopUp('in', 'Sign In');
    }
}

function reportContent(){
    var user = firebase.auth().currentUser;
    if(user){
        if(scope.index.reportVars.reason !== '' && !scope.index.buttonPressed.report){
            scope.index.buttonPressed.report = true;
            scope.index.reportVars.uid = user.uid;
            if(document.querySelector('.report-email')){
                scope.index.reportVars.email = document.querySelector('.report-email').value;
            }
            firebase.database().ref('/report').push(scope.index.reportVars).then(function(){
                scope.index.buttonPressed.report = false;
                fadePopUp('out');
            });
        }
    } else {
        fadePopUp('in', 'Sign In');
    }
}

function displayPosts(arrayPosts, firstTimeRetrieval){
    if(arrayPosts !== null && arrayPosts !== undefined){
        if(firstTimeRetrieval){
            scope.index.posts = [];
            scope.index.postsEnd = false;
            local.iteration++;

            if(arrayPosts.length < local.postsRetrieved){
                scope.index.postsEnd = true;
            }
        } else {
            if(arrayPosts.length < local.postsRetrieved - 1){
                scope.index.postsEnd = true;
            }
        }
        arrayPosts.reverse();
        arrayPosts.forEach(function(item){
            item.channelInfo = {
                name: '',
                profilePic: ''
            };

            item.actions = {
                like: '',
                usefulList: ''
            }
            scope.index.posts.push(item);
            getChannelIdentity(scope.index.posts.length - 1, parseInt(local.iteration + ' '));
            getActionsButtonsValues(scope.index.posts.length - 1, parseInt(local.iteration + ' '));
        });

        scope.index.retrievingData = false;
        scope.$applyAsync();
    } else {
        scope.index.posts = [];
        local.iteration++;
        scope.index.postsEnd = true;
        scope.index.retrievingData = false;
        scope.$applyAsync();
    }
}

function getChannelIdentity(index, iteration){
    if(iteration === local.iteration){ // if it is reziduu from previous, won't replace new current value in array
        if(scope.index.page.pageName === 'channel' && index >= 1 && scope.index.posts[0].channelInfo.name !== ''){
            scope.index.posts[index].channelInfo = scope.index.posts[0].channelInfo;
        } else {
            firebase.database().ref('/public/channels/' + scope.index.posts[index].channel + '/identity').once('value').then(function(snapshot){
                if(iteration === local.iteration && snapshot.val() !== null){
                    scope.index.posts[index].channelInfo = {
                        name: snapshot.val().name,
                        profilePic: snapshot.val().profilePic
                    }
                }
                scope.$applyAsync();
            });
        }
    }
}

function getActionsButtonsValues(index, iteration){
    if(iteration === local.iteration){ 
        if(firebase.auth().currentUser !== null){
            var uid = firebase.auth().currentUser.uid;
            firebase.database().ref('private/' + uid + '/likes/' + scope.index.posts[index].id).once('value').then(function(snapshot){
                if(iteration === local.iteration){ 
                    if(snapshot.val() === null || snapshot.val().state === 'off'){
                        scope.index.posts[index].actions.like = false;
                    } else {
                        scope.index.posts[index].actions.like = true;
                    }
                    scope.$applyAsync();
                }
            });

            firebase.database().ref('private/' + uid + '/usefulList').orderByChild('/id').equalTo(scope.index.posts[index].id).once('value').then(function(snapshot){
                if(iteration === local.iteration){ 
                    if(snapshot.val() === null){
                        scope.index.posts[index].actions.usefulList = false;
                    } else {
                        scope.index.posts[index].actions.usefulList = true;
                        var key = Object.keys(snapshot.val());
                        scope.index.posts[index].actions.usefulListId = key[0];
                    }
                    scope.$applyAsync();
                }
            });
        } else {
            scope.index.posts[index].actions = {
                like: false,
                usefulList: false
            }
            scope.$applyAsync();
        }
    }
}

//
function likeClick(index){
    if(scope.index.posts[index].actions.like !== ''){
        var bool = scope.index.posts[index].actions.like;
        scope.index.posts[index].actions.like = '';
        if(firebase.auth().currentUser !== null){
            var uid = firebase.auth().currentUser.uid;
            if(bool){
                //unlike
                firebase.database().ref('private/' + uid + '/likes/' +scope.index.posts[index].id).update({
                    state:'off',
                    type:'post'
                }).then(function(){
                    scope.index.posts[index].actions.like = false;
                    scope.index.posts[index].values.likes--;
                    scope.$applyAsync();
                });
            } else {
                //like
                firebase.database().ref('private/' + uid + '/likes/' + scope.index.posts[index].id).set({
                    state:'on',
                    type:'post'
                }).then(function(){
                    scope.index.posts[index].actions.like = true;
                    scope.index.posts[index].values.likes++;
                    scope.$applyAsync();
                });
            }
        } else {
            scope.index.posts[index].actions.like = false;
            scope.index.fadePopUp('in', 'Sign In');
        }
    }
}

function usefulListClick(index){
    if(scope.index.posts[index].actions.usefulList !== ''){
        var bool = scope.index.posts[index].actions.usefulList;
        scope.index.posts[index].actions.usefulList = '';
        if(firebase.auth().currentUser !== null){
            var uid = firebase.auth().currentUser.uid;
            if(bool){
                //unUsefulList
                firebase.database().ref('private/' + uid + '/usefulList/' + scope.index.posts[index].actions.usefulListId).remove().then(function(){
                    scope.index.posts[index].actions.usefulList = false;
                    scope.$applyAsync();
                });
            } else {
                //usefulList
                var key = firebase.database().ref('private/' + uid + '/usefulList/').push({id: scope.index.posts[index].id}).key;
                function continueKey(){
                    if(key){
                        scope.index.posts[index].actions.usefulListId = key;
                        scope.index.posts[index].actions.usefulList = true;
                        scope.$applyAsync();
                    } else {
                        setTimeout(continueKey, 50);
                    }
                }
                continueKey();
            }
        } else {
            scope.index.posts[index].actions.usefulList = false;
            scope.index.fadePopUp('in', 'Sign In');
        }
    }
}

function subscribeClickIndex(index){
    var channel = scope.index.channels[index];

    if(channel.values.subscribed !== ''){
        if(firebase.auth().currentUser !== null){
            var uid = firebase.auth().currentUser.uid;
            if(channel.values.subscribed){
                //unsubscribe
                channel.values.subscribed = '';
                firebase.database().ref('private/' + uid + '/subscribed/' + channel.id).update({state:'off'}).then(function(){
                    channel.values.subscribed = false;
                    channel.values.subscribers--;
                    scope.$applyAsync();
                });
            } else {
                //subscribe
                channel.values.subscribed = '';
                firebase.database().ref('private/' + uid + '/subscribed/' + channel.id).set({state:'on'}).then(function(){
                    channel.values.subscribed = true;
                    channel.values.subscribers++;
                    scope.$applyAsync();
                });
            }
        } else {
            scope.index.fadePopUp('in', 'Sign In');
        }
    }
}

function sendFeedback(){
    if(!scope.index.feedbackSending && scope.index.feedbackText !== ''){
        scope.index.feedbackSending = true;
        firebase.database().ref('/feedback').push({
            text: scope.index.feedbackText,
            uid: firebase.auth().currentUser ? firebase.auth().currentUser.uid : 'anonym'
        }).then(function(){
            scope.index.feedbackSending = false;
            scope.index.feedbackText = '';
            scope.index.fadePopUp('out');
        });
    }
}
