
var id = '';

function initSearchContent(){
    scope.search = {
        searchText: '',
        type: 'channel',
        textChanged: textChanged,
        moreChannels: moreChannels,
        morePosts: morePosts,
        moreCollections: moreCollections,
        changeType: changeType
    }

    var itteration = 0;

    initSomeVals();
}

function changeType(type, searchText){
    scope.search.type = type;

    if(searchText !== '' && searchText !== undefined){
        initSomeVals();
        textChanged(searchText);
    }
}

function initSomeVals(){
    scope.index.channels = [];
    scope.index.channelsEnd = false;
    local.lastSearchText = '';
    scope.index.posts = [];
    scope.index.postsEnd = false;
    local.prevId = '';
    scope.index.collections = [];
    scope.index.collectionsEnd = false;

    local.resultsFound = false;
}

function textChanged(searchText){
    local.lastSearchText = searchText;
    if(!scope.index.retrievingData){
        scope.index.retrievingData = true;

        if(scope.search.type === 'channel'){
            id = searchText.toLowerCase().replace(/\s/g, "");
            if(id !== '' && !(local.prevId !== '' && id.indexOf(local.prevId) !== -1 && (!local.resultsFound) && id.length > 1)){
                firebase.database().ref('public/channels').orderByKey().startAt(id).endAt(id + "\uf8ff").limitToLast(local.searchLimit).once('value').then(function(snapshot){
                    local.prevId = id;
                    local.resultsFound = false;
                    var obj = snapshot.val();
                    if(obj !== null){
                        local.resultsFound = true;
                        var array = Object.keys(snapshot.val());
                        scope.index.endAt = array[0];
                    }

                    if(local.lastSearchText !== ''){
                        if(local.lastSearchText.toLowerCase().replace(/\s/g, "") === id){
                            displayChannels(obj, true);
                        } else {
                            scope.index.retrievingData = false;
                            textChanged(local.lastSearchText);
                        }
                    } else {
                        displayChannels(null);
                    }
                    scope.$applyAsync();
                });
            } else {
                displayChannels(null);
                scope.$applyAsync();
            }
        }

        if(scope.search.type === 'post'){
            id = searchText.toLowerCase().replace(/\s/g, "");
            if(id !== '' && !(local.prevId !== '' && id.indexOf(local.prevId) !== -1 && (!local.resultsFound) && id.length > 1)){
                firebase.database().ref('public/posts').orderByChild('content/titleSearch').startAt(id).endAt(id + "\uf8ff").limitToLast(local.searchLimit).once('value').then(function(snapshot){
                    local.prevId = id;
                    local.resultsFound = false;
                    var obj = snapshot.val();
                    var array = [];
                    var resultArray = [];
                    if(obj !== null){
                        local.resultsFound = true;
                        array = Object.keys(snapshot.val());
                        function compare(a,b){
                            if(obj[a].content.titleSearch < obj[b].content.titleSearch){
                                return -1;
                            }
                            if(obj[a].content.titleSearch > obj[b].content.titleSearch){
                                return 1;
                            }
                            return 0;
                        }
                        array.sort(compare);
                        array.forEach(function(item){
                            resultArray.push(obj[item]);
                            resultArray[resultArray.length - 1].id = item;
                        });
                        scope.index.endAt = obj[array[0]].content.titleSearch;
                    }

                    if(local.lastSearchText !== ''){
                        if(local.lastSearchText.toLowerCase().replace(/\s/g, "") === id){
                            displayPosts(resultArray, true);
                        } else {
                            scope.index.retrievingData = false;
                            textChanged(local.lastSearchText);
                        }
                    } else {
                        displayPosts(null);
                    }
                    if(array.length === local.searchLimit){
                        scope.index.postsEnd = false;
                    } else {
                        scope.index.postsEnd = true;
                    }
                    scope.$applyAsync();
                });
            } else {
                displayPosts(null);
                scope.$applyAsync();
            }
        }

        if(scope.search.type === 'collection'){
            id = searchText.toLowerCase().replace(/\s/g, "");
            if(id !== '' && !(local.prevId !== '' && id.indexOf(local.prevId) !== -1 && (!local.resultsFound) && id.length > 1)){
                firebase.database().ref('public/collections').orderByChild('content/nameSearch').startAt(id).endAt(id + "\uf8ff").limitToLast(local.searchLimit).once('value').then(function(snapshot){
                    local.prevId = id;
                    local.resultsFound = false;
                    var obj = snapshot.val();
                    if(obj !== null){
                        local.resultsFound = true;
                        var array = Object.keys(snapshot.val());
                        function compare(a,b){
                            if(obj[a].content.nameSearch < obj[b].content.nameSearch){
                                return -1;
                            }
                            if(obj[a].content.nameSearch > obj[b].content.nameSearch){
                                return 1;
                            }
                            return 0;
                        }
                        array.sort(compare);

                        scope.index.endAt = obj[array[0]].content.nameSearch;
                    }

                    if(local.lastSearchText !== ''){
                        if(local.lastSearchText.toLowerCase().replace(/\s/g, "") === id){
                            displayCollections(obj, true);
                        } else {
                            scope.index.retrievingData = false;
                            textChanged(local.lastSearchText);
                        }
                    } else {
                        displayCollections(null);
                    }
                    scope.$applyAsync();
                });
            } else {
                displayCollections(null);
                scope.$applyAsync();
            }
        }
    }
}

//move to index
function displayChannels(jsonChannels, firstTimeRetrieval){
    if(jsonChannels !== null && jsonChannels !== undefined){
        var array = Object.keys(jsonChannels);
        if(firstTimeRetrieval){
            scope.index.channels = [];
            scope.index.channelsEnd = false;
            local.iteration++;

            if(array.length < local.searchLimit){
                scope.index.channelsEnd = true;
            }
        } else {
            if(array.length < local.searchLimit - 1){
                scope.index.channelsEnd = true;
            }
        }
        array.reverse();

        array.forEach(function(item){
            var obj = jsonChannels[item];
            obj.id = item;
            obj.values.subscribed = '';
            scope.index.channels.push(obj);

            checkSubscribtion(scope.index.channels.length - 1);
        });

        scope.index.retrievingData = false;
        scope.$applyAsync();
    } else {
        scope.index.channels = [];
        local.iteration++;
        scope.index.channelsEnd = true;
        scope.index.retrievingData = false;
        scope.$applyAsync();
    }
}

function checkSubscribtion(index){
    if(firebase.auth().currentUser !== null){
        var uid = firebase.auth().currentUser.uid;
        firebase.database().ref('private/' + uid + '/subscribed/' + scope.index.channels[index].id).once('value').then(function(snapshot){
            if(snapshot.val() === null || snapshot.val().state === 'off'){
                scope.index.channels[index].values.subscribed = false;
            } else {
                scope.index.channels[index].values.subscribed = true;
            }
            scope.$applyAsync();
        });
    } else {
        scope.index.channels[index].values.subscribed = false;
        scope.$applyAsync();
    }
}

function moreChannels(){
    scope.index.retrievingData = true;
    firebase.database().ref('public/channels').orderByKey().startAt(id).endAt(scope.index.endAt).limitToLast(local.searchLimit).once('value').then(function(snapshot){
        var obj = snapshot.val();
        if(obj !== null){
            var array = Object.keys(snapshot.val());
            delete obj[array[array.length - 1]];

            if(array !== undefined && array.length > 1){
                scope.index.endAt = array[0];
            }
        }

        if(local.lastSearchText !== ''){
            local.prevId = id;
            if(local.lastSearchText.toLowerCase().replace(/\s/g, "") === id){
                displayChannels(obj);
            } else {
                scope.index.retrievingData = false;
                textChanged(local.lastSearchText);
            }
        } else {
            displayChannels(null);
            local.prevId = '';
        }
        scope.$applyAsync();
    });
}

function morePosts(){
    scope.index.retrievingData = true;
    firebase.database().ref('public/posts').orderByChild('content/titleSearch').startAt(id).endAt(scope.index.endAt).limitToLast(local.searchLimit).once('value').then(function(snapshot){
        var obj = snapshot.val();
        console.log(obj);
        var resultArray = [];
        if(obj !== null){
            var array = Object.keys(snapshot.val());
            function compare(a,b){
                if(obj[a].content.titleSearch < obj[b].content.titleSearch){
                    return -1;
                }
                if(obj[a].content.titleSearch > obj[b].content.titleSearch){
                    return 1;
                }
                return 0;
            }
            array.sort(compare);
            array.pop();
            array.forEach(function(item){
                resultArray.push(obj[item]);
                resultArray[resultArray.length - 1].id = item;
            });

            if(array.length > 0){
                scope.index.endAt = obj[array[0]].content.titleSearch;
            }

            if(array.length < local.searchLimit - 1){
                scope.index.postsEnd = true;
            }
        }
        
        if(local.lastSearchText !== ''){
            local.prevId = id;
            if(local.lastSearchText.toLowerCase().replace(/\s/g, "") === id){
                displayPosts(resultArray);
            } else {
                scope.index.retrievingData = false;
                textChanged(local.lastSearchText);
            }
        } else {
            displayPosts(null);
            local.prevId = '';
        }
        scope.$applyAsync();
    });
}

function displayCollections(jsonCollections, firstTimeRetrieval){
    if(jsonCollections !== null && jsonCollections !== undefined){
        var array = Object.keys(jsonCollections);
        if(firstTimeRetrieval){
            scope.index.collections = [];
            scope.index.collectionsEnd = false;
            local.iteration++;

            if(array.length < local.searchLimit){
                scope.index.collectionsEnd = true;
            }
        } else {
            if(array.length < local.searchLimit - 1){
                scope.index.collectionsEnd = true;
            }
        }
        array.reverse();

        array.forEach(function(item){
            var obj = jsonCollections[item];
            obj.id = item;
            obj.values.subscribed = '';
            scope.index.collections.push(obj);
        });

        scope.index.retrievingData = false;
        scope.$applyAsync();
    } else {
        scope.index.collections = [];
        local.iteration++;
        scope.index.collectionsEnd = true;
        scope.index.retrievingData = false;
        scope.$applyAsync();
    }

    console.log(scope.index.collections);
}

function moreCollections(){
    scope.index.retrievingData = true;
    firebase.database().ref('public/collections').orderByChild('content/nameSearch').startAt(id).endAt(scope.index.endAt).limitToLast(local.searchLimit).once('value').then(function(snapshot){
        var obj = snapshot.val();
        if(obj !== null){
            var array = Object.keys(snapshot.val());
            function compare(a,b){
                if(obj[a].content.nameSearch < obj[b].content.nameSearch){
                    return -1;
                }
                if(obj[a].content.nameSearch > obj[b].content.nameSearch){
                    return 1;
                }
                return 0;
            }
            array.sort(compare);
            var itemDeleted;
            array.forEach(function(item){
                if(obj[item].content.nameSearch === scope.index.endAt){
                    delete obj[item];
                    itemDeleted = item;
                }
            });
            if(array.length > 1){
                scope.index.endAt = array[0] !== itemDeleted ? obj[array[0]].content.nameSearch : obj[array[1]].content.nameSearch;
            }
        }

        if(local.lastSearchText !== ''){
            local.prevId = id;
            if(local.lastSearchText.toLowerCase().replace(/\s/g, "") === id){
                displayCollections(obj);
            } else {
                scope.index.retrievingData = false;
                textChanged(local.lastSearchText);
            }
        } else {
            displayCollections(null);
            local.prevId = '';
        }
        scope.$applyAsync();
    });
}
