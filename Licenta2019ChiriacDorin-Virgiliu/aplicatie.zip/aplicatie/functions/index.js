const functions = require('firebase-functions');
const admin = require('firebase-admin');
admin.initializeApp();

var trendyMin = 20, hotMin = 100, limitDelete = 30;

exports.share = functions.https.onRequest((request, response) => {
    var id = request.url.split('/').reverse()[0];

    return admin.database().ref('public/posts/' + id).once("value").then(function(snapshot){
        if(snapshot.val() !== null){
            response.send(`
            <!DOCTYPE html>
            <html ng-app="useful_indeed" ng-controller="useful_indeed_controller" >
                <head>
                    <meta charset="utf-8">
                    <meta name="viewport" content="width=device-width, initial-scale=1.0">
                    <link rel="icon" href="../../resources/images/pin.png" type="image/png">
                    <title>USEFUL INDEED - If it's usable, well... then it's useful indeed.</title>

                    <meta name="twitter:card" content="summary">
                    <meta name="twitter:title" content="` + snapshot.val().content.title + `">
                    <meta name="twitter:description" content="USABILITY: ` + snapshot.val().content.usability + `">
                    <meta name="twitter:image" content="` + snapshot.val().ref.imageURL + `">

                    <meta property="og:type" content="website"/>
                    <meta name="og:url" content="https://usefulindeed-c3831.firebaseapp.com/post/` + id + `">
                    <meta name="og:title" content="` + snapshot.val().content.title + `">
                    <meta name="og:description" content="USABILITY: ` + snapshot.val().content.usability + `">
                    <meta name="og:image" content="` + snapshot.val().ref.imageURL + `">
                    <meta name="fb:app_id" content="164294400940503">
                </head>
                <body></body>
                <script>
                    window.location.href = "https://usefulindeed-c3831.firebaseapp.com/post/` + id +`";
                </script>
            </html>
            `);
        } else {
            response.send(`<script>window.location.href = "https://usefulindeed-c3831.firebaseapp.com";</script>`);
        }

        return 'ok';
    });
});

exports.createPost = functions.database.ref('/public/posts/{postId}/content/collection')
    .onCreate((snapshot, context) => {
        var collection = snapshot._data;
        var postId = context.params.postId;

        return admin.database().ref('/public/posts/' + postId).once("value").then(function(snapshotPost) {
            return admin.database().ref('public/collections/' + collection + '/values').transaction(function(values) {
                if (values !== null) {
                    return {
                        nrPosts: values.nrPosts + 1,
                        thumbnail: snapshotPost.val().ref.imageURL
                    };
                } else {
                    return 0;
                }
            }, function(error, committed, snapshot){}, true);
        }).catch(function(e){console.log(e)});
    });

exports.updatePostFilters = functions.database.ref('/public/posts/{postId}/content')
    .onUpdate((snapshot, context) => {
        var postId = context.params.postId;
        var collection = snapshot.after.val().collection;
        var type = snapshot.after.val().type;
        var category = snapshot.after.val().category;

        return admin.database().ref('public/posts/' + postId + '/values').transaction(function(values) {
            if (values !== null) {
                var rating = 1;
                if(values.likes >= trendyMin && values.likes < hotMin){
                    rating = 2;
                }
                if(values.likes >= hotMin){
                    rating = 3;
                }

                return {
                    likes: values.likes,
                    comments: values.comments,
                    rating: values.rating,
                    channel_new: values.channel_new,
                    channel_hot: values.channel_hot,


                    collection: collection + postId,
                    type_new: type + postId,
                    type_hot: type + rating + postId,
                    category_new: category.toUpperCase() + postId,
                    category_hot: category.toUpperCase() + rating + postId
                };
            } else {
                return 0;
            }
        }, function(error, committed, snapshot){}, true);
    });

exports.updateCollections = functions.database.ref('/public/posts/{postId}/content/collection')
    .onUpdate((snapshot, context) => {
        var collBefore = snapshot.before.val();
        var collAfter = snapshot.after.val();
        var postId = context.params.postId;   

        if(collBefore !== collAfter){
            return admin.database().ref('/public/posts/').orderByChild('content/collection').equalTo(collAfter).limitToLast(1)
            .once("value").then(function(snapshotPost) {
                var ids = Object.keys(snapshotPost.val());
                return admin.database().ref('public/collections/' + collAfter + '/values').transaction(function(values) {
                    if (values !== null) {
                        return {
                            nrPosts: values.nrPosts + 1,
                            thumbnail: snapshotPost.val()[ids[0]].ref.imageURL
                        };
                    } else {
                        return 0;
                    }
                }, function(error, committed, snapshot){}, true).then(function(){
                    return admin.database().ref('/public/posts/').orderByChild('content/collection').equalTo(collBefore).limitToLast(1)
                    .once("value").then(function(snapshotPost) {
                        var ids = snapshotPost.val() ? Object.keys(snapshotPost.val()) : '';
                        return admin.database().ref('public/collections/' + collBefore + '/values').transaction(function(values) {
                            if (values !== null) {
                                return {
                                    nrPosts: values.nrPosts - 1,
                                    thumbnail: values.nrPosts > 1 ? snapshotPost.val()[ids[0]].ref.imageURL : 'https://firebasestorage.googleapis.com/v0/b/usefulindeed-c3831.appspot.com/o/defaults%2Fdefault-coverPic.svg?alt=media&token=2f1f353c-c9a7-4a3e-85f2-b00bcc2fc912'
                                };
                            } else {
                                return 0;
                            }
                        }, function(error, committed, snapshot){}, true);
                    }).catch(function(e){console.log(e)});
                }).catch(function(e){console.log(e)});
            });
        }
    });

exports.subscribe = functions.database.ref('/private/{uid}/subscribed/{chId}')
    .onCreate((snapshot, context) => {
        var chId = context.params.chId;

        return admin.database().ref('public/channels/' + chId + '/values').transaction(function(values) {
            if (values !== null) {
                return {
                    likes: values.likes,
                    subscribers: (values.subscribers || 0) + 1
                };
            } else {
                return 0;
            }
        }, function(error, committed, snapshot){}, true).then(function(){
            return admin.database().ref('public/channels/' + chId + '/uid').once("value").then(function(snapshotCh) {
                var ownerUid = snapshotCh.val();

                return admin.database().ref('private/' + ownerUid + '/stopNotifications/' + chId).once("value").then(function(snapshot){
                    if(snapshot.val() === null){
                        return admin.database().ref('private/' + ownerUid + '/notifications').push({
                            type: 'subscribed',
                            for: chId,
                            time: Date.now()
                        });
                    }
                    return null;
                });
            });
        });
    });

exports.subscribeUnsubscribe = functions.database.ref('/private/{uid}/subscribed/{chId}/state')
    .onUpdate((snapshot, context) => {
        var chId = context.params.chId;
        var state = snapshot.after.val() ? snapshot.after.val() : 'off';

        return admin.database().ref('public/channels/' + chId + '/values').transaction(function(values) {
            if (values !== null) {
                return {
                    likes: values.likes,
                    subscribers: (values.subscribers || 0) + (state === 'on' ? 1 : -1)
                };
            } else {
                return 0;
            }
        }, function(error, committed, snapshot){}, true);
    });

exports.like = functions.database.ref('/private/{uid}/likes/{id}')
    .onCreate((snapshot, context) => {
        var type = snapshot._data.type;
        if(type === 'post'){
            var postId = context.params.id;

            return admin.database().ref('public/posts/' + postId).once("value").then(function(snapshot) {
                var channel = snapshot.val().channel;
                var type = snapshot.val().content.type;
                var category = snapshot.val().content.category;
                var ownerUid = snapshot.val().uid;

                return admin.database().ref('public/posts/' + postId + '/values').transaction(function(values) {
                    if (values !== null) {
                        var likes = (values.likes || 0) + 1;
                        var rating = 1;
                        if(likes >= trendyMin && likes < hotMin){
                            rating = 2;
                        }
                        if(likes >= hotMin){
                            rating = 3;
                        }
        
                        return {
                            collection: values.collection,
                            comments: values.comments,

                            likes: likes,
                            rating: rating + postId,
                            channel_new: channel + '--/-//-' + postId,
                            channel_hot: channel + '--/-//-' + rating + postId,

                            type_new: type + postId,
                            type_hot: type + rating + postId,
                            category_new: category.toUpperCase() + postId,
                            category_hot: category.toUpperCase() + rating + postId
                        };
                    } else {
                        return 0;
                    }
                }, function(error, committed, snapshot){}, true).then(function(){
                    return admin.database().ref('public/channels/' + channel + '/values').transaction(function(values) {
                        if (values !== null) {
                            return {
                                likes: (values.likes || 0) + 1,
                                subscribers: values.subscribers
                            };
                        } else {
                            return 0;
                        }
                    }, function(error, committed, snapshot){}, true).then(function(){
                        return admin.database().ref('private/' + ownerUid + '/stopNotifications/' + postId).once("value").then(function(snapshot){
                            if(snapshot.val() === null){
                                return admin.database().ref('private/' + ownerUid + '/notifications').push({
                                    type: 'like',
                                    for: postId,
                                    time: Date.now()
                                });
                            }
                            return null;
                        });
                    });
                });
            });
        } else {
            var commentId = context.params.id;

            return admin.database().ref('public/comments/' + commentId).once('value').then(function(snapshot){
                var forId = snapshot.val().for;
                var fromId = snapshot.val().from;
                var ownerUid = snapshot.val().uid;
                var parentCommentId = snapshot.val().parentCommentId;

                return admin.database().ref('public/comments/' + commentId + '/values').transaction(function(values) {
                    if (values !== null) {
                        var likes = (values.likes || 0) + 1;

                        if(type === 'comment'){
                            return {
                                replays: values.replays,
                                likes: likes,
                                comment_new: forId + commentId,
                                comment_hot: forId + likes + commentId
                            }
                        } else {
                            return {
                                likes: likes,
                                replay: parentCommentId + commentId,

                            }
                        }
                    } else {
                        return 0;
                    }
                }, function(error, committed, snapshot){}, true).then(function(){
                    if(type === 'comment'){
                        return admin.database().ref('private/' + ownerUid + '/stopNotifications/' + commentId).once("value").then(function(snapshot){
                            if(snapshot.val() === null){
                                return admin.database().ref('private/' + ownerUid + '/notifications').push({
                                    type: 'comment-like',
                                    postId: forId,
                                    commentId: commentId,
                                    time: Date.now()
                                });
                            }
                            return null;
                        });
                    } else {
                        return admin.database().ref('private/' + ownerUid + '/stopNotifications/' + commentId).once("value").then(function(snapshot){
                            if(snapshot.val() === null){
                                return admin.database().ref('private/' + ownerUid + '/notifications').push({
                                    type: 'replay-like',
                                    postId: forId,
                                    commentId: commentId,
                                    parentCommentId: parentCommentId,
                                    time: Date.now()
                                });
                            }
                            return null;
                        });
                    }
                });
            });
        }
    });

exports.likeUnlike = functions.database.ref('/private/{uid}/likes/{id}')
    .onUpdate((snapshot, context) => {
        var type = snapshot.after.val().type;
        var state = snapshot.after.val().state ? snapshot.after.val().state : 'off';
        if(type === 'post'){
            var postId = context.params.id;

            return admin.database().ref('public/posts/' + postId).once("value").then(function(snapshot) {
                var channel = snapshot.val().channel;
                var type = snapshot.val().content.type;
                var category = snapshot.val().content.category;
                var ownerUid = snapshot.val().uid;

                return admin.database().ref('public/posts/' + postId + '/values').transaction(function(values) {
                    if (values !== null) {
                        var likes = (values.likes || 0) + (state === 'on' ? 1 : -1);
                        var rating = 1;
                        if(likes >= trendyMin && likes < hotMin){
                            rating = 2;
                        }
                        if(likes >= hotMin){
                            rating = 3;
                        }
        
                        return {
                            collection: values.collection,
                            comments: values.comments,

                            likes: likes,
                            rating: rating + postId,
                            channel_new: channel + '--/-//-' + postId,
                            channel_hot: channel + '--/-//-' + rating + postId,

                            type_new: type + postId,
                            type_hot: type + rating + postId,
                            category_new: category.toUpperCase() + postId,
                            category_hot: category.toUpperCase() + rating + postId
                        };
                    } else {
                        return 0;
                    }
                }, function(error, committed, snapshot){}, true).then(function(){
                    return admin.database().ref('public/channels/' + channel + '/values').transaction(function(values) {
                        if (values !== null) {
                            return {
                                likes: (values.likes || 0) + (state === 'on' ? 1 : -1),
                                subscribers: values.subscribers
                            };
                        } else {
                            return 0;
                        }
                    }, function(error, committed, snapshot){}, true);
                });
            });
        } else {
            var commentId = context.params.id;

            return admin.database().ref('public/comments/' + commentId).once('value').then(function(snapshot){
                var type = snapshot.val().type;
                var forId = snapshot.val().for;
                var fromId = snapshot.val().from;
                var ownerUid = snapshot.val().uid;
                var parentCommentId = snapshot.val().parentCommentId;

                return admin.database().ref('public/comments/' + commentId + '/values').transaction(function(values) {
                    if (values !== null) {
                        var likes = (values.likes || 0) + (state === 'on' ? 1 : -1);

                        if(type === 'comment'){
                            return {
                                replays: values.replays,
                                likes: likes,
                                comment_new: forId + commentId,
                                comment_hot: forId + likes + commentId
                            }
                        } else {
                            return {
                                likes: likes,
                                replay: parentCommentId + commentId
                            }
                        }
                    } else {
                        return 0;
                    }
                }, function(error, committed, snapshot){}, true);
            });
        }
    });

exports.comment = functions.database.ref('/public/comments/{id}')
    .onCreate((snapshot, context) => {
        var id = context.params.id;
        var comment = snapshot._data;
        if(comment.type === "comment"){
            return admin.database().ref('public/posts/' + comment.for + '/values').transaction(function(values) {
                if (values !== null) {
                    return {
                        collection: values.collection,
                        comments: (values.comments || 0) + 1,

                        likes: values.likes,
                        rating: values.rating,
                        channel_new: values.channel_new,
                        channel_hot: values.channel_hot,

                        type_new: values.type_new,
                        type_hot: values.type_hot,
                        category_new: values.category_new,
                        category_hot: values.category_hot
                    }
                } else {
                    return 0;
                }
            }, function(error, committed, snapshot){}, true).then(function(){
                return admin.database().ref('public/posts/' + comment.for).once("value").then(function(snapshot){
                    var ownerUid = snapshot.val().uid;
                    if(ownerUid !== comment.uid){
                        return admin.database().ref('private/' + ownerUid + '/stopNotifications/' + comment.for).once("value").then(function(snapshot){
                            if(snapshot.val() === null){
                                return admin.database().ref('private/' + ownerUid + '/notifications').push({
                                    type: 'comment',
                                    for: comment.for,
                                    from: comment.from,
                                    commentId: id,
                                    time: Date.now()
                                });
                            }
                            return null;
                        });
                    }
                    return null;
                });
            });
        } else {
            return admin.database().ref('public/comments/' + comment.parentCommentId + '/values').transaction(function(values) {
                if (values !== null) {
                    return {
                        likes: values.likes,
                        comment_new: values.comment_new,
                        comment_hot: values.comment_hot,
                        replays: (values.replays || 0) + 1
                    };
                } else {
                    return 0;
                }
            }, function(error, committed, snapshot){}, true).then(function(){
                return admin.database().ref('public/comments/' + comment.parentCommentId).once("value").then(function(snapshot){
                    var ownerUid = snapshot.val().uid;
                    var followers = Object.keys(snapshot.val().followers.uids);
                    function sendNotification(index){
                        if(index < followers.length){
                            if(followers[index] === ownerUid){
                                if(ownerUid !== comment.uid){
                                    return admin.database().ref('private/' + ownerUid + '/notifications').push({
                                        type: 'replayed-comment',
                                        for: comment.for,
                                        from: comment.from,
                                        parentCommentId: comment.parentCommentId,
                                        commentId: id,
                                        time: Date.now()
                                    }).then(function(){
                                        return sendNotification(index + 1);
                                    });
                                } else {
                                    return sendNotification(index + 1);
                                }
                            } else {
                                if(followers[index] !== comment.uid){
                                    return admin.database().ref('private/' + followers[index] + '/notifications').push({
                                        type: 'answered-replay',
                                        for: comment.for,
                                        from: comment.from,
                                        parentCommentId: comment.parentCommentId,
                                        time: Date.now()
                                    }).then(function(){
                                        return sendNotification(index + 1);
                                    });
                                } else {
                                    return sendNotification(index + 1);
                                }
                            }
                        }
                    }
                    return sendNotification(0);
                });
            });
        }
    });

//onDelete
exports.deleteComment = functions.database.ref('/public/comments/{id}')
    .onDelete((snapshot, context) => {
        var comment = snapshot.val();
        var id = context.params.id;
        if(comment.type === 'comment'){
            return admin.database().ref('public/posts/' + comment.for).once('value').then(function(snapshot){
                if(snapshot.val() !== null && snapshot.val().values !== 0){
                    return admin.database().ref('public/posts/' + comment.for + '/values').transaction(function(values) {
                        if (values !== null) {
                            return {
                                collection: values.collection,
                                comments: values.comments - 1,
        
                                likes: values.likes,
                                rating: values.rating,
                                channel_new: values.channel_new,
                                channel_hot: values.channel_hot,
        
                                type_new: values.type_new,
                                type_hot: values.type_hot,
                                category_new: values.category_new,
                                category_hot: values.category_hot
                            }
                        } else {
                            return 0;
                        }
                    }, function(error, committed, snapshot){}, true);
                } else {
                    return 'ok';
                }
            }).then(function(){
                var lastId = id + "\uf8ff";
                var endIds = false;

                function recursionDelete(){
                    if(!endIds){
                        return admin.database().ref('public/comments').orderByChild('values/replay').startAt(id).endAt(lastId).limitToLast(limitDelete).once('value').then(function(snapshot){
                            var obj = snapshot.val();
                            function compare(a,b){
                                if(obj[a]['values']['replay'] < obj[b]['values']['replay']){
                                    return -1;
                                }
                                if(obj[a]['values']['replay'] > obj[b]['values']['replay']){
                                    return 1;
                                }
                                return 0;
                            }
                            if(snapshot.val() !== null){
                                var array = Object.keys(snapshot.val());
                                array.sort(compare);
                                lastId = array[0];
                                if(array.length < limitDelete){
                                    endIds = true;
                                }
                                
                                for(var i = 0; i< array.length; i++){
                                    admin.database().ref('public/comments/' + array[i]).remove();
                                }
                            } else {
                                endIds = true;
                            }       
                            
                            return recursionDelete();
                        });
                    } else {
                        return 'ok';
                    }
                }
                
                return recursionDelete();
            });
        } else {
            return admin.database().ref('public/comments/' + comment.parentCommentId).once('value').then(function(snapshot){
                if(snapshot.val() !== null && snapshot.val().values !== 0){
                    return admin.database().ref('public/comments/' + comment.parentCommentId + '/values').transaction(function(values) {
                        console.log('deleted replay ' + comment.text);
                        if (values !== null) {
                            return {
                                likes: values.likes,
                                comment_new: values.comment_new,
                                comment_hot: values.comment_hot,
                                replays: values.replays - 1
                            };
                        } else {
                            return 0;
                        }
                    }, function(error, committed, snapshot){}, true);
                } else {
                    return 'ok';
                }
            });
        }
    });

exports.deletePost = functions.database.ref('/public/posts/{id}')
    .onDelete((snapshot, context) => {
        var post = snapshot.val();
        var id = context.params.id;
        return admin.database().ref('public/collections/' + post.content.collection).once('value').then(function(snapshot){
            if(snapshot.val() !== null && snapshot.val().values !== 0){
                return admin.database().ref('/public/posts/').orderByChild('content/collection').equalTo(post.content.collection).limitToLast(1)
                    .once("value").then(function(snapshotPost) {
                        var ids = snapshotPost.val() ? Object.keys(snapshotPost.val()) : '';
                        return admin.database().ref('public/collections/' + post.content.collection + '/values').transaction(function(values) {
                            if (values !== null) {
                                return {
                                    nrPosts: values.nrPosts - 1,
                                    thumbnail: values.nrPosts > 1 ? snapshotPost.val()[ids[0]].ref.imageURL : 'https://firebasestorage.googleapis.com/v0/b/usefulindeed-c3831.appspot.com/o/defaults%2Fdefault-coverPic.svg?alt=media&token=2f1f353c-c9a7-4a3e-85f2-b00bcc2fc912'
                                };
                            } else {
                                return 0;
                            }
                        }, function(error, committed, snapshot){}, true);
                    })
            } else {
                return 'ok';
            }
        }).then(function(){
            return admin.database().ref('public/channels/' + post.channel).once('value').then(function(snapshot){
                if(snapshot.val() !== null && snapshot.val().values !== 0){
                    return admin.database().ref('public/channels/' + post.channel + '/values').transaction(function(values) {
                        if (values !== null) {
                            return {
                                likes: values.likes - post.values.likes,
                                subscribers: values.subscribers
                            };
                        } else {
                            return 0;
                        }
                    }, function(error, committed, snapshot){}, true);
                } else {
                    return 'ok';
                }
            });
        }).then(function(){
            var lastId = id + "\uf8ff";
            var endIds = false;

            function recursionDelete(){
                if(!endIds){
                    return admin.database().ref('public/comments').orderByChild('values/comment_new').startAt(id).endAt(lastId).limitToLast(limitDelete).once('value').then(function(snapshot){
                        var obj = snapshot.val();
                        function compare(a,b){
                            if(obj[a]['values']['comment_new'] < obj[b]['values']['comment_new']){
                                return -1;
                            }
                            if(obj[a]['values']['comment_new'] > obj[b]['values']['comment_new']){
                                return 1;
                            }
                            return 0;
                        }
                        if(snapshot.val() !== null){
                            var array = Object.keys(snapshot.val());
                            array.sort(compare);
                            lastId = array[0];
                            if(array.length < limitDelete){
                                endIds = true;
                            }
                            
                            for(var i = 0; i< array.length; i++){
                                admin.database().ref('public/comments/' + array[i]).remove();
                            }
                        } else {
                            endIds = true;
                        }       
                        
                        return recursionDelete();
                    });
                } else {
                    return 'ok';
                }
            }            
            return recursionDelete();
        });
    });

exports.deleteCollection = functions.database.ref('/public/collections/{id}')
    .onDelete((snapshot, context) => {
        var collection = snapshot.val();
        var id = context.params.id;

        var lastId = id + "\uf8ff";
        var endIds = false;

        function recursionDelete(){
            if(!endIds){
                return admin.database().ref('public/posts').orderByChild('values/collection').startAt(id).endAt(lastId).limitToLast(limitDelete).once('value').then(function(snapshot){
                    var obj = snapshot.val();
                    function compare(a,b){
                        if(obj[a]['values']['collection'] < obj[b]['values']['collection']){
                            return -1;
                        }
                        if(obj[a]['values']['collection'] > obj[b]['values']['collection']){
                            return 1;
                        }
                        return 0;
                    }
                    if(snapshot.val() !== null){
                        var array = Object.keys(snapshot.val());
                        array.sort(compare);
                        lastId = array[0];
                        if(array.length < limitDelete){
                            endIds = true;
                        }
                        
                        for(var i = 0; i< array.length; i++){
                            admin.database().ref('public/posts/' + array[i]).remove();
                        }
                    } else {
                        endIds = true;
                    }       
                    
                    return recursionDelete();
                });
            } else {
                return 'ok';
            }
        }            
        return recursionDelete();
    });

exports.deleteChannel = functions.database.ref('/public/channels/{id}')
    .onDelete((snapshot, context) => {
        var channel = snapshot.val();
        var id = context.params.id;

        return admin.database().ref('private/' + channel.uid + '/user/channels/' + id).remove().then(function(){
            return admin.database().ref('public/collections').orderByChild('channel').equalTo(id).once('value').then(function(snapshot){
                if(snapshot.val() !== null){
                    var array = Object.keys(snapshot.val());
                    for(var i = 0; i< array.length; i++){
                        admin.database().ref('public/collections/' + array[i]).remove();
                    }
                }
                return 'ok';
            });
        });
    });

exports.deleteAccount = functions.database.ref('/private/{uid}/user')
    .onDelete((snapshot, context) => {
        var user = snapshot.val();

        if(user.channels){
            var array = Object.keys(user.channels);
            array.forEach(function(item){
                admin.database().ref('public/channels/' + item).remove();
            });
        }

        return 'ok';
    });

exports.unsubscribeDeletedUser = functions.database.ref('/private/{uid}/subscribed/{chId}')
    .onDelete((snapshot, context) => {
        var chId = context.params.chId;

        return admin.database().ref('public/channels/' + chId).once('value').then(function(snapshot){
            if(snapshot.val() !== null && snapshot.val().values !== 0){
                return admin.database().ref('public/channels/' + chId + '/values').transaction(function(values) {
                    if (values !== null) {
                        return {
                            likes: values.likes,
                            subscribers: values.subscribers -1
                        };
                    } else {
                        return 0;
                    }
                }, function(error, committed, snapshot){}, true);
            } else {
                return 'ok';
            }
        });
    });
